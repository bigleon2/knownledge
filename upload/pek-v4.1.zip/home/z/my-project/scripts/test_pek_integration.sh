#!/bin/bash
# Integration test script for PEK v4.1 Python monolith
cd /home/z/my-project/download
rm -f pek_v4.1.db

# Start server in background
python3 pek_v4.1.py --port 5432 > /tmp/pek_server.log 2>&1 &
SERVER_PID=$!
sleep 3

# Check server is running
if ! kill -0 $SERVER_PID 2>/dev/null; then
    echo "FAIL: Serveur non demarre"
    cat /tmp/pek_server.log
    exit 1
fi
echo "OK: Serveur demarre (PID=$SERVER_PID)"

# T1: Health
echo "--- T1: Health ---"
R=$(curl -s http://localhost:5432/api/debug)
echo "$R" | python3 -c "import sys,json;d=json.load(sys.stdin);print(f'  version={d[\"version\"]} status={d[\"status\"]} modules={d[\"modules\"]}')"

# T2: Create session
echo "--- T2: Create session ---"
R=$(curl -s -X POST http://localhost:5432/api/sessions -H "Content-Type: application/json" -d '{}')
SID=$(echo "$R" | python3 -c "import sys,json;print(json.load(sys.stdin)['id'])")
echo "  Session ID: $SID"

# T3: Get session
echo "--- T3: Get session ---"
curl -s http://localhost:5432/api/sessions/$SID | python3 -c "import sys,json;d=json.load(sys.stdin);print(f'  title={d[\"title\"]} nextStep={d[\"nextStep\"]}')"

# T4: Execute step 1
echo "--- T4: Etape 1 (comprendre) ---"
curl -s -X POST http://localhost:5432/api/sessions/$SID/execute \
  -H "Content-Type: application/json" \
  -d '{"currentStep":1,"userInput":"Chatbot IA avec React Next.js et Prisma pour RAG"}' \
  | python3 -c "import sys,json;d=json.load(sys.stdin);print(f'  step={d[\"step\"]} name={d[\"stepName\"]} next={d[\"nextStep\"]} out={len(d[\"output\"])}c')"

# T5: Execute step 2 (decomposition + blocks)
echo "--- T5: Etape 2 (decomposer + blocs A-J) ---"
curl -s -X POST http://localhost:5432/api/sessions/$SID/execute \
  -H "Content-Type: application/json" \
  -d '{"currentStep":2,"userInput":"Suite analyse"}' \
  | python3 -c "import sys,json;d=json.load(sys.stdin);print(f'  step={d[\"step\"]} type={d.get(\"projectType\",\"?\")} blocs={d.get(\"selectedBlocks\",[])} next={d[\"nextStep\"]}')"

# T6: Skip step (must 400)
echo "--- T6: Saut etape (expect 400) ---"
CODE=$(curl -s -o /dev/null -w "%{http_code}" -X POST http://localhost:5432/api/sessions/$SID/execute \
  -H "Content-Type: application/json" -d '{"currentStep":5,"userInput":"saut"}')
echo "  HTTP $CODE (expected 400): $([ "$CODE" = "400" ] && echo PASS || echo FAIL)"

# T7: Re-execute step 1 (must 409)
echo "--- T7: Reexec etape 1 (expect 409) ---"
CODE=$(curl -s -o /dev/null -w "%{http_code}" -X POST http://localhost:5432/api/sessions/$SID/execute \
  -H "Content-Type: application/json" -d '{"currentStep":1,"userInput":"retry"}')
echo "  HTTP $CODE (expected 409): $([ "$CODE" = "409" ] && echo PASS || echo FAIL)"

# T8: Knowledge base
echo "--- T8: Knowledge base ---"
curl -s http://localhost:5432/api/knowledge | python3 -c "import sys,json;d=json.load(sys.stdin);print(f'  version={d[\"version\"]} modules={d[\"moduleCount\"]} kb_len={len(d[\"content\"])}')"

# T9: Knowledge module 4
echo "--- T9: Knowledge module=4 ---"
curl -s "http://localhost:5432/api/knowledge?module=4" | python3 -c "import sys,json;d=json.load(sys.stdin);print(f'  module={d[\"module\"]} len={len(d[\"content\"])}')"

# T10: Export
echo "--- T10: Export Markdown ---"
CTYPE=$(curl -s -o /dev/null -w "%{content_type}" http://localhost:5432/api/sessions/$SID/export)
echo "  Content-Type: $CTYPE"
echo "$CTYPE" | grep -q "markdown" && echo "  PASS" || echo "  FAIL"

# T11: Session inconnue (404)
echo "--- T11: Session inconnue (expect 404) ---"
CODE=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:5432/api/sessions/inexistant)
echo "  HTTP $CODE (expected 404): $([ "$CODE" = "404" ] && echo PASS || echo FAIL)"

# Cleanup
kill $SERVER_PID 2>/dev/null
rm -f pek_v4.1.db
echo ""
echo "=== SERVEUR ARRETE ==="