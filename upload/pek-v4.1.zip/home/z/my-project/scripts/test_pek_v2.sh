#!/bin/bash
cd /home/z/my-project/download
rm -f pek_v4.1.db

python3 pek_v4.1.py --port=5435 > /tmp/pek4.log 2>&1 &
sleep 3

if ! curl -s http://localhost:5435/api/debug > /dev/null 2>&1; then
    echo "FAIL: Server not running"
    cat /tmp/pek4.log
    exit 1
fi

echo "T1: $(curl -s http://localhost:5435/api/debug | python3 -c "import sys,json;d=json.load(sys.stdin);print(f'Health v={d[\"version\"]} ok={d[\"status\"]}')")"

S=$(curl -s -X POST http://localhost:5435/api/sessions -H "Content-Type: application/json" -d '{}')
SID=$(echo "$S" | python3 -c "import sys,json;print(json.load(sys.stdin)['id'])")
echo "T2: Session created ($SID)"

echo "T3: $(curl -s -X POST http://localhost:5435/api/sessions/$SID/execute -H 'Content-Type: application/json' -d '{"currentStep":1,"userInput":"Chatbot React Next.js Prisma RAG"}' | python3 -c "import sys,json;d=json.load(sys.stdin);print(f'Step1: step={d[\"step\"]} name={d[\"stepName\"]} next={d[\"nextStep\"]} out={len(d[\"output\"])}c')")"

echo "T4: $(curl -s -X POST http://localhost:5435/api/sessions/$SID/execute -H 'Content-Type: application/json' -d '{"currentStep":2,"userInput":"suite"}' | python3 -c "import sys,json;d=json.load(sys.stdin);print(f'Step2: type={d.get(\"projectType\")} blocs={d.get(\"selectedBlocks\")} next={d[\"nextStep\"]}')")"

C5=$(curl -s -o /dev/null -w "%{http_code}" -X POST http://localhost:5435/api/sessions/$SID/execute -H 'Content-Type: application/json' -d '{"currentStep":5,"userInput":"x"}')
echo "T5: Skip step -> HTTP $C5 $([ "$C5" = "400" ] && echo PASS || echo FAIL)"

C6=$(curl -s -o /dev/null -w "%{http_code}" -X POST http://localhost:5435/api/sessions/$SID/execute -H 'Content-Type: application/json' -d '{"currentStep":1,"userInput":"x"}')
echo "T6: Reexec step1 -> HTTP $C6 $([ "$C6" = "409" ] && echo PASS || echo FAIL)"

echo "T7: $(curl -s http://localhost:5435/api/knowledge | python3 -c "import sys,json;d=json.load(sys.stdin);print(f'KB: v={d[\"version\"]} mod={d[\"moduleCount\"]}')")"

echo "T8: $(curl -s 'http://localhost:5435/api/knowledge?module=4' | python3 -c "import sys,json;d=json.load(sys.stdin);print(f'M4: len={len(d[\"content\"])}')")"

CT=$(curl -s -D- http://localhost:5435/api/sessions/$SID/export 2>/dev/null | head -3 | grep -i content-type)
echo "T9: Export -> $CT $([ -n "$CT" ] && echo PASS || echo FAIL)"

C10=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:5435/api/sessions/nonexistent)
echo "T10: Unknown session -> HTTP $C10 $([ "$C10" = "404" ] && echo PASS || echo FAIL)"

pkill -f "python3 pek_v4.1.py" 2>/dev/null
rm -f pek_v4.1.db
echo ""
echo "=== DONE ==="