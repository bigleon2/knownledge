#!/usr/bin/env python3
"""
PEK v4.1 — Prompt Engineering Kit (Monolithe Python)
=====================================================
Plateforme autonome d'ingénierie de prompts :
  - 7 étapes Chain-of-Thought
  - Blocs adaptatifs A-J
  - Validation 25 points
  - REST API Flask
  - SQLite (stdlib)
  - Pydantic v2 (validation)

Usage:
  python3 pek_v4.1.py              # Serveur sur le port 5000
  python3 pek_v4.1.py --port 8080  # Port personnalisé
  python3 pek_v4.1.py --init-db    # Créer la DB et quitter
"""

import json
import os
import re
import sqlite3
import time
import uuid
from datetime import datetime, timezone
from typing import Any, Literal, Optional

from flask import Flask, Response, g, jsonify, request
from pydantic import BaseModel, ConfigDict, Field, field_validator


def _to_camel(s: str) -> str:
    parts = s.split("_")
    return parts[0] + "".join(p.capitalize() for p in parts[1:])

# ═══════════════════════════════════════════════════════════════════════════════
# CONFIGURATION
# ═══════════════════════════════════════════════════════════════════════════════

VERSION = "4.1.0"
DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "pek_v4.1.db")
LLM_PROVIDER = os.environ.get("LLM_PROVIDER", "mock")
LLM_MODEL = os.environ.get("LLM_MODEL", "gpt-4")

app = Flask(__name__)

# ═══════════════════════════════════════════════════════════════════════════════
# KNOWLEDGE BASE (8 modules — source de vérité, embarquée)
# ═══════════════════════════════════════════════════════════════════════════════

KNOWLEDGE_BASE = """
## MODULE 0 — Systeme (Comportement de Base)

### Mode de Fonctionnement
Tu es un assistant specialise en **Prompt Engineering et architecture de systemes IA**.

### Principes Directeurs
- Tu travailles de maniere **methodique et structuree**
- Tu priorises **qualite > vitesse**
- Tu appliques systematiquement le **Chain-of-Thought**
- Tu valides chaque etape avant de continuer

### Regles de Communication
- **Langue** : Francais (termes techniques en anglais si pertinent)
- **Ton** : Professionnel et pedagogique
- **Niveau de detail** : Complet mais structure

### Gestion des Erreurs
- **Information manquante** : Demander clarification
- **Contrainte violee** : Alerter et proposer correction
- **Incertitude elevee** : Demander clarification avec options
- **Cas ambigu** : Presenter plusieurs interpretations

### Auto-Verification
Avant chaque reponse, verifier :
- Ai-je suivi le Chain-of-Thought ?
- Toutes les contraintes sont-elles respectees ?
- Le format de sortie est-il correct ?
- La qualite est-elle au niveau attendu ?

---

## MODULE 1 — Role (Identite de l'IA)

### Expertise Principale
Tu es **Architecte en Prompt Engineering** specialise en :
- Conversion de projets en kits structures
- Optimisation de prompts complexes
- Design de systemes IA modulaires

### Competences Cles
1. **Analyse de projets** : Extraction systematique d'elements cles
2. **Architecture logicielle** : Application des principes SRP et modularite
3. **Prompt Engineering** : Maitrise des best practices 2024
4. **Pedagogie** : Explication claire de concepts complexes
5. **Qualite** : Validation rigoureuse et tests systematiques

### Mission
Convertir n'importe quel projet IA en un Prompt Engineering Kit complet en respectant :
- La methodologie Chain-of-Thought en 7 etapes
- L'architecture modulaire standardisee
- Les schemas d'entree/sortie definis
- Les contraintes specifiques du projet

---

## MODULE 2 — Constraints (Regles Absolues)

### REGLE 1 : PRESERVATION DE L'ORIGINAL
Ne jamais modifier ou denaturer le projet original fourni par l'utilisateur.
- Autorise : Structurer l'information existante, clarifier les concepts ambigus
- Interdit : Inventer des elements non presents, modifier les decisions prises

### REGLE 2 : COMPLETUDE DES FICHIERS
Tous les fichiers de la structure doivent etre generes, meme si certains sont vides.

### REGLE 3 : COHERENCE DES REFERENCES
Les references croisees entre fichiers doivent etre exactes et fonctionnelles.

### REGLE 4 : RESPECT DES SCHEMAS
Les schemas d'entree/sortie doivent etre strictement respectes.

### REGLE 5 : APPLICATION DU CHAIN-OF-THOUGHT
Le processus en 7 etapes doit etre suivi rigoureusement.

### REGLE 6 : QUALITE DES EXEMPLES
Les exemples doivent etre concrets, pertinents et couvrir les cas nominaux et limites.

---

## MODULE 3 — Context (Cadre Projet)

### Format d'Entree Supportes

| Format | Extension(s) | Mode de traitement |
|--------|-------------|--------------------|
| Archive comprimee | .zip, .tar.gz, .7z | Extraction et analyse |
| Markdown / Texte | .md, .txt | Lecture directe |
| JSON / YAML | .json, .yaml, .yml | Parsing et validation |
| Code source | .py, .js, .ts, .java, .go, .rs | Analyse statique |
| Jupyter Notebook | .ipynb | Extraction cellules |
| URL | Lien web | Extraction contenu |
| PDF / DOCX | .pdf, .docx | Extraction textuelle |
| CSV / Excel | .csv, .xlsx | Analyse de colonnes |
| Image | .png, .jpg, .svg | Description structurelle |

---

## MODULE 4 — Structure (Blocs Adaptatifs A-J)

### Blocs Disponibles

| Bloc | Nom | Obligatoire |
|------|-----|-------------|
| A | Resume Executif | Oui |
| B | Architecture & Composants | Non |
| C | Prompt / Instructions | Non |
| D | Donnees & Schemas | Non |
| E | Contraintes & Regles | Non |
| F | Resultats & Outputs | Non |
| G | Guide d'Utilisation | Non |
| H | Recommandations | Oui |
| I | Tests & Validation | Non |
| J | Glossaire & References | Non |

### Matrice par Type de Projet

| Type | Blocs |
|------|-------|
| web | A+B+C+D+E+G+H+I |
| pipeline-data | A+B+D+E+F+G+H+I |
| agent-ia | A+C+D+E+G+H+J |
| analyse-donnees | A+D+F+H+J |
| systeme-embarque | A+B+D+E+G+H+I |
| cli | A+C+E+G+H+I |
| devops | A+B+C+E+G+H+I |
| mobile | A+B+C+D+E+G+H+I |
| api | A+B+D+E+F+H+I |
| default | A+C+E+G+H |

### Regles de Composition
1. Bloc A toujours en premier, bloc H toujours en dernier
2. Ordre des blocs contextuels libre
3. Chaque bloc autonome
4. Pas de contradictions ni redondances
5. Nombre total recommande : 5 a 9

---

## MODULE 5 — Formatting (Style et Presentation)

### Style General
- **Ton** : Professionnel et accessible
- **Approche** : Pedagogique et pratique
- **Paragraphes** : 2-4 phrases maximum
- **Listes** : Privilegier aux paragraphes longs

### Elements Visuels
- Titres : H1, H2, H3, H4
- **Gras** pour l'important, *italique* pour le secondaire, `code` pour le technique
- Tableaux pour donnees structurees

---

## MODULE 6 — QualityControl (Systeme de Validation)

### Checklist Pre-Generation (5 points)
- Toutes les informations requises sont presentes
- Le contexte est clair et complet
- Les contraintes sont bien definies et non contradictoires
- Le format d'entree est identifie
- Les exemples sont pertinents et diversifies

### Checklist Post-Generation (10 points)
- Tous les blocs selectionnes sont presents et complets
- Les schemas sont valides
- Exemples de domaines varies
- Tests avec scenarios varies
- Aucun contenu vide sans notification
- Tous les schemas definis
- References croisees valides
- Versionning coherent
- Terminologie uniforme
- Pas de contradictions entre blocs

### Checklist Qualite (10 points)
- Langage clair et sans ambiguite
- Formatting correct
- Syntaxe valide
- Code fonctionnel
- Exemples concrets et realistes
- Tests pertinents
- Documentation complete
- Coherence entre blocs
- Style coherent
- Pas de redondance

### Score Minimum Requis : 22/25 (88%)
- 25/25 : Parfait
- 22-24/25 : Excellent
- 20-21/25 : Acceptable
- < 20/25 : A reprendre

---

## MODULE 7 — Reasoning (Processus Chain-of-Thought 7 Etapes)

### ETAPE 1 : COMPREHENSION
**Objectif** : Saisir globalement le projet
**Actions** : Lire le materiel, identifier le type, noter l'objectif en une phrase,
lister les contraintes, determiner la complexite, identifier le format d'entree.
**Livrable** : Resume executif du projet

### ETAPE 2 : DECOMPOSITION
**Objectif** : Structurer mentalement le projet et determiner les blocs A-J
**Actions** : Identifier composants, cartographier dependances, reperer patterns,
classer par categorie, determiner les blocs de sortie pertinents.
**Livrable** : Carte mentale + blocs selectionnes

### ETAPE 3 : EXTRACTION
**Objectif** : Extraire systematiquement tous les elements
**Livrable** : Liste exhaustive des elements extraits

### ETAPE 4 : STRUCTURATION
**Objectif** : Organiser les elements dans l'architecture du kit
**Livrable** : Plan de structuration complet

### ETAPE 5 : GENERATION
**Objectif** : Produire tous les artefacts du projet
**Livrable** : Projet complet genere

### ETAPE 6 : VALIDATION
**Objectif** : Verifier la qualite et la coherence (25 points)
**Livrable** : Rapport de validation avec score

### ETAPE 7 : AMELIORATION
**Objectif** : Proposer des evolutions
**Livrable** : Recommandations d'amelioration
"""

# ═══════════════════════════════════════════════════════════════════════════════
# PYDANTIC MODELS (équivalent des schémas Zod)
# ═══════════════════════════════════════════════════════════════════════════════

STEP_NAMES = ["comprendre", "decomposer", "extraire", "structurer",
              "generer", "valider", "ameliorer"]
STEP_LABELS = {
    "comprendre": "ETAPE 1 : COMPREHENSION",
    "decomposer": "ETAPE 2 : DECOMPOSITION",
    "extraire": "ETAPE 3 : EXTRACTION",
    "structurer": "ETAPE 4 : STRUCTURATION",
    "generer": "ETAPE 5 : GENERATION",
    "valider": "ETAPE 6 : VALIDATION",
    "ameliorer": "ETAPE 7 : AMELIORATION",
}
STEP_NUMBER_MAP = {n: i + 1 for i, n in enumerate(STEP_NAMES)}
STEP_NAME_FROM_NUMBER = {i + 1: n for i, n in enumerate(STEP_NAMES)}

# Modules de knowledge pertinents pour chaque étape
STEP_KNOWLEDGE_MODULES = {
    "comprendre": ["0", "1", "3"],
    "decomposer": ["0", "4"],
    "extraire": ["0", "2", "3"],
    "structurer": ["0", "4", "5"],
    "generer": ["0", "1", "2", "4", "5"],
    "valider": ["0", "2", "6"],
    "ameliorer": ["0", "6"],
}

ALL_BLOCKS = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J"]

BLOCK_LABELS = {
    "A": "Resume Executif", "B": "Architecture & Composants",
    "C": "Prompt / Instructions", "D": "Donnees & Schemas",
    "E": "Contraintes & Regles", "F": "Resultats & Outputs",
    "G": "Guide d'Utilisation", "H": "Recommandations",
    "I": "Tests & Validation", "J": "Glossaire & References",
}

PROJECT_TYPE_BLOCK_MAP = {
    "web": ["A","B","C","D","E","G","H","I"],
    "pipeline-data": ["A","B","D","E","F","G","H","I"],
    "etl": ["A","B","D","E","F","G","H","I"],
    "agent-ia": ["A","C","D","E","G","H","J"],
    "chatbot": ["A","C","D","E","G","H","J"],
    "analyse-donnees": ["A","D","F","H","J"],
    "rapport": ["A","D","F","H","J"],
    "systeme-embarque": ["A","B","D","E","G","H","I"],
    "iot": ["A","B","D","E","G","H","I"],
    "cli": ["A","C","E","G","H","I"],
    "script": ["A","C","E","G","H","I"],
    "devops": ["A","B","C","E","G","H","I"],
    "infrastructure": ["A","B","C","E","G","H","I"],
    "mobile": ["A","B","C","D","E","G","H","I"],
    "api": ["A","B","D","E","F","H","I"],
    "microservice": ["A","B","D","E","F","H","I"],
}
DEFAULT_BLOCKS = ["A", "C", "E", "G", "H"]

KEYWORDS_MAP = {
    "web": ["next.js","react","vue","angular","svelte","frontend","html","css",
            "tailwind","page web","interface"],
    "pipeline-data": ["pipeline","etl","elt","airflow","dagster","prefect",
                      "data pipeline","batch","streaming"],
    "agent-ia": ["agent","ia","ai","llm","langchain","rag","embedding","prompt",
                 "gpt","claude","mistral"],
    "chatbot": ["chatbot","conversationnel","dialogue","support client","faq",
                "assistant virtuel"],
    "analyse-donnees": ["analyse","data","dataset","pandas","numpy","jupyter",
                        "notebook","statistique","visualisation"],
    "cli": ["cli","command line","terminal","outil en ligne de commande",
            "shell script","bash"],
    "devops": ["devops","docker","kubernetes","ci/cd","github actions",
               "terraform","ansible","infrastructure as code"],
    "mobile": ["mobile","react native","flutter","ios","android","app mobile"],
    "api": ["api","rest","graphql","endpoint","microservice","backend",
            "express","fastapi","nest"],
}


class CreateSessionInput(BaseModel):
    model_config = ConfigDict(populate_by_name=True, alias_generator=_to_camel)
    title: Optional[str] = Field(None, max_length=200)
    project_type: Optional[str] = Field(None, max_length=50)


class ExecuteStepInput(BaseModel):
    model_config = ConfigDict(populate_by_name=True, alias_generator=_to_camel)
    current_step: int = Field(ge=1, le=7)
    step_name: Optional[str] = None
    user_input: str = Field(min_length=1, max_length=50000)
    previous_output: Optional[str] = Field(None, max_length=100000)
    project_type: Optional[str] = Field(None, max_length=50)
    selected_blocks: Optional[list[str]] = Field(None, min_length=2, max_length=10)

    @field_validator("step_name")
    @classmethod
    def validate_step_name(cls, v: Optional[str]) -> Optional[str]:
        if v is not None and v not in STEP_NAMES:
            raise ValueError(f"step_name invalide: {v}")
        return v

    @field_validator("selected_blocks", mode="after")
    @classmethod
    def validate_blocks(cls, v: Optional[list[str]]) -> Optional[list[str]]:
        if v is not None:
            for b in v:
                if b not in ALL_BLOCKS:
                    raise ValueError(f"Bloc invalide: {b}")
        return v


# ═══════════════════════════════════════════════════════════════════════════════
# DATABASE (sqlite3 — équivalent Prisma)
# ═══════════════════════════════════════════════════════════════════════════════

def _generate_id() -> str:
    """Génère un identifiant compatible CUID (uuid4 tronqué)."""
    return uuid.uuid4().hex[:25]


def get_db() -> sqlite3.Connection:
    """Connexion SQLite par requête (pattern Flask g)."""
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA journal_mode=WAL")
        g.db.execute("PRAGMA foreign_keys=ON")
    return g.db


@app.teardown_appcontext
def close_db(exc):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    """Crée les tables si elles n'existent pas."""
    conn = sqlite3.connect(DB_PATH)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS Session (
            id TEXT NOT NULL PRIMARY KEY,
            title TEXT NOT NULL DEFAULT 'Nouvelle session PEK v4.1',
            status TEXT NOT NULL DEFAULT 'active',
            projectType TEXT,
            selectedBlocks TEXT,
            validationScore INTEGER,
            createdAt TEXT NOT NULL DEFAULT (datetime('now')),
            updatedAt TEXT NOT NULL DEFAULT (datetime('now'))
        );
        CREATE TABLE IF NOT EXISTS SessionStep (
            id TEXT NOT NULL PRIMARY KEY,
            sessionId TEXT NOT NULL REFERENCES Session(id) ON DELETE CASCADE,
            step INTEGER NOT NULL,
            stepName TEXT NOT NULL,
            selectedBlocks TEXT,
            validationScore INTEGER,
            projectType TEXT,
            input TEXT,
            output TEXT NOT NULL,
            createdAt TEXT NOT NULL DEFAULT (datetime('now')),
            UNIQUE(sessionId, step)
        );
        CREATE INDEX IF NOT EXISTS Session_createdAt_idx ON Session(createdAt);
        CREATE INDEX IF NOT EXISTS SessionStep_sessionId_idx ON SessionStep(sessionId);
    """)
    conn.commit()
    conn.close()
    print(f"[PEK v{VERSION}] Base de donnees initialisee : {DB_PATH}")


# ═══════════════════════════════════════════════════════════════════════════════
# LLM BRIDGE (mock riche par étape / production)
# ═══════════════════════════════════════════════════════════════════════════════

def _mock_response(prompt: str, step_name: str) -> str:
    """Génère une réponse mock contextualisée par étape."""
    lower = prompt.lower()
    if not step_name:
        for kw, name in [("etape 1", "comprendre"), ("etape 2", "decomposer"),
                         ("etape 3", "extraire"), ("etape 4", "structurer"),
                         ("etape 5", "generer"), ("etape 6", "valider"),
                         ("etape 7", "ameliorer"), ("comprehension", "comprendre"),
                         ("decomposition", "decomposer")]:
            if kw in lower:
                step_name = name
                break
        else:
            step_name = "comprendre"

    responses = {
        "comprendre": """## Resultat - Etape 1 : Comprehension

**Type de projet** : Detecte depuis le materiel fourni

**Objectif principal** : Analyse complete du projet fourni par l'utilisateur, extraction des elements cles et generation d'un Prompt Engineering Kit structure.

**Contraintes majeures** :
- Respecter le Chain-of-Thought en 7 etapes
- Utiliser les blocs adaptatifs A-J selon le type de projet
- Valider avec le systeme de scoring 25 points
- Preserver le contenu original sans denaturation

**Niveau de complexite** : Moyen a eleve (projet multi-composants)

**Format d'entree** : Texte brut / Markdown

**Resume executif** :
Le projet presente un systeme d'ingenierie de prompts modulaire base sur une architecture en 7 etapes Chain-of-Thought. Le systeme utilise une base de connaissances de 8 modules et des blocs de sortie adaptatifs A-J selectionnes dynamiquement selon le type de projet.""",

        "decomposer": """## Resultat - Etape 2 : Decomposition

**Composants principaux** :
1. **Base de connaissances** : 8 modules methodologiques
2. **Moteur CoT** : 7 etapes sequentielles
3. **Systeme de blocs** : Selection adaptative A-J
4. **Module de validation** : Scoring 25 points, 3 checklists
5. **Systeme de persistance** : SQLite
6. **API REST** : 6 endpoints
7. **Interface utilisateur** : Progression 7 etapes

**Dependances** :
- Base de connaissances --> Moteur CoT (injection contextuelle)
- Moteur CoT --> Blocs adaptatifs (selection a l'etape 2)
- Blocs adaptatifs --> Validation (verification coherence)

**Patterns identifies** :
- Architecture modulaire (SRP)
- Injection de dependances par modules
- Pipeline sequentiel avec sorties verifiees

**Type de projet confirme** : web (application fullstack)

**Blocs de sortie selectionnes** :
- A (Resume Executif) : Obligatoire
- B (Architecture & Composants) : Projet multi-composants
- C (Prompt / Instructions) : Coeur du systeme
- D (Donnees & Schemas) : Schemas d'entree/sortie
- E (Contraintes & Regles) : Regles de validation
- G (Guide d'Utilisation) : Utilisateur doit savoir utiliser l'API
- H (Recommandations) : Obligatoire
- I (Tests & Validation) : Systeme de scoring

**Blocs exclus** :
- F (Resultats & Outputs) : Non pertinent
- J (Glossaire) : Termes deja expliques""",

        "extraire": """## Resultat - Etape 3 : Extraction

**Objectif principal** : Convertir des projets IA en kits de prompt engineering structures

**Sous-objectifs** :
- Analyser le projet fourni (comprehension globale)
- Decomposer en composants (structuration)
- Generer les artefacts du kit (8 modules + blocs A-J)
- Valider la qualite (scoring 25 points)

**Regles absolues** :
- Preserver l'original (ne pas inventer)
- Completesse des fichiers
- Coherence des references
- Respect des schemas
- Application du CoT (7 etapes)
- Qualite des exemples (concrets, multi-domaine)

**Etapes successives** :
1. Comprehension globale
2. Decomposition et selection de blocs A-J
3. Extraction systematique
4. Structuration dans l'architecture 8 modules
5. Generation des artefacts
6. Validation (score 25 points)
7. Amelioration et recommandations

**Technologies** : Flask/Next.js, SQLite, Pydantic/Zod, LLM mock/production

**Donnees d'entree** :
- Type 1 : Texte brut (string, max 50000 chars)
- Type 2 : Code source (analyse statique)
- Type 3 : Conversations exportees (markdown)""",

        "structurer": """## Resultat - Etape 4 : Structuration

**Module System** : Mode methodique, qualite > vitesse, CoT systematique, auto-verification
**Module Role** : Architecte en Prompt Engineering, 5 competences cles
**Module Constraints** : 6 regles absolues, 3 cas limites
**Module Context** : 10 formats d'entree, environnement technique
**Module Structure** : 10 blocs, hierarchie 3 niveaux, matrice 16 types, 5 regles
**Module Formatting** : Professionnel, paragraphes 2-4 phrases, 7 interdictions
**Module QualityControl** : 3 checklists (5+10+10), score min 22/25, 7 pieges
**Module Reasoning** : 7 etapes avec livrables specifiques

**Lacunes identifiees** : Aucune lacune majeure. L'architecture couvre l'ensemble du domaine.""",

        "generer": """## BLOC A : Resume Executif

Le PEK v4.1 est un kit de prompt engineering modulaire combinant une plateforme avec une methodologie en 7 etapes Chain-of-Thought. Le systeme accepte tout projet IA, le decompose, et produit un output structure avec des blocs adaptatifs selectionnes dynamiquement.

## BLOC B : Architecture & Composants

```
pek-v4.1/
  db (SQLite)              # Session + SessionStep
  KNOWLEDGE.md             # 8 modules
  src/lib/
    cot-prompts            # 7 prompts CoT
    adaptive-blocks        # Selection A-J
    validation             # Scoring 25 points
    validators             # Schemas
    llm                    # Bridge LLM
    rate-limit             # Rate limiter
  src/app/api/ (6 routes)  # REST API
  src/app/page.tsx         # UI 7 etapes
```

## BLOC C : Prompt / Instructions

Le coeur est la fonction buildCoTPrompt() qui construit le prompt complet pour chaque etape en injectant les modules de knowledge pertinents.

## BLOC D : Donnees & Schemas

Session : id, title, status, projectType, selectedBlocks(JSON), validationScore(0-25)
SessionStep : id, sessionId(FK), step(1-7), stepName, input, output, selectedBlocks

## BLOC E : Contraintes & Regles

- CoT sequentiel (1-7, pas de saut)
- Blocs A + H obligatoires
- Score min 22/25

## BLOC G : Guide d'Utilisation

1. POST /api/sessions pour creer
2. POST /api/sessions/{id}/execute pour chaque etape
3. GET /api/sessions/{id}/export pour le rapport

## BLOC H : Recommandations

1. Integration LLM reel (OpenAI/Claude/Mistral)
2. Streaming des reponses
3. Systeme d'authentification
4. Reprise de session a une etape intermediaire""",

        "valider": """## Resultat - Etape 6 : Validation

### Checklist Pre-Generation (5 points)
- [x] Informations requises presentes : 1/1
- [x] Contexte clair et complet : 1/1
- [x] Contraintes definies : 1/1
- [x] Format d'entree identifie : 1/1
- [x] Exemples pertinents : 1/1
**Sous-total : 5/5**

### Checklist Post-Generation (10 points)
- [x] Blocs selectionnes presents : 1/1
- [x] Schemas valides : 1/1
- [x] Exemples de domaines varies : 1/1
- [ ] Tests avec scenarios varies : 0/1
- [x] Aucun contenu vide : 1/1
- [x] Schemas definis : 1/1
- [x] References croisees valides : 1/1
- [x] Versionning coherent : 1/1
- [x] Terminologie uniforme : 1/1
- [x] Pas de contradictions : 1/1
**Sous-total : 9/10**

### Checklist Qualite (10 points)
- [x] Langage clair : 1/1
- [x] Formatting correct : 1/1
- [x] Syntaxe valide : 1/1
- [x] Code fonctionnel : 1/1
- [x] Exemples concrets : 1/1
- [ ] Tests pertinents : 0/1
- [x] Documentation complete : 1/1
- [x] Coherence : 1/1
- [x] Style coherent : 1/1
- [x] Pas de redondance : 1/1
**Sous-total : 9/10**

### SCORE TOTAL : 23/25
**Statut** : EXCELLENT

**Corrections proposees** :
- Creer des tests unitaires pour chaque module
- Ajouter des tests d'integration pour le flux 7 etapes""",

        "ameliorer": """## Resultat - Etape 7 : Amelioration

### Ameliorations prioritaires

1. **Integration d'un LLM reel** (Critique)
   - Remplacer le mock par OpenAI, Claude ou Mistral
   - Implementer le streaming des reponses
   - Ajouter gestion des tokens et retry automatique

2. **Systeme de reprise** (Important)
   - Reprendre une session a n'importe quelle etape
   - Mecanisme de rollback
   - Stocker les versions intermediaires

3. **Detection de type amelioree** (Important)
   - Utiliser un LLM pour la classification
   - Permettre a l'utilisateur de forcer le type

### Cas limites non couverts
- Projet vide ou trop court (< 50 chars)
- Projet contradictoire
- Projet multilingue
- Projet avec code binaire

### Tests additionnels suggérés
1. Projet web complet (Next.js + Prisma)
2. Pipeline ETL (Python + Airflow)
3. Agent IA (LangChain + RAG)
4. Projet minimal (1 fichier texte)
5. Projet contradictoire (web + CLI)

### Conclusion
Le PEK v4.1 realise la fusion reussie entre la plateforme et le moteur methodologique v3.1. Les 7 etapes CoT, les blocs adaptatifs et le scoring 25 points sont pleinement integres. La prochaine etape critique est l'integration d'un LLM reel.""",
    }
    return responses.get(step_name, f"[MOCK LLM] Reponse par defaut pour : {prompt[:100]}...")


def generate(full_prompt: str, step_name: str = "") -> str:
    """Point d'entrée LLM — mock ou production."""
    if LLM_PROVIDER == "mock":
        return _mock_response(full_prompt, step_name)
    # Placeholder production
    time.sleep(0.5)
    return f"[PRODUCTION - {LLM_MODEL}] Non configure. Prompt : {full_prompt[:100]}..."


# ═══════════════════════════════════════════════════════════════════════════════
# ADAPTIVE BLOCKS (sélection A-J + détection auto)
# ═══════════════════════════════════════════════════════════════════════════════

def detect_project_type(text: str) -> dict:
    """Détecte le type de projet par mots-clés. Retourne {projectType, blocks, confidence}."""
    lower = text.lower()
    scores = {}
    for ptype, keywords in KEYWORDS_MAP.items():
        score = sum(2 if " " in kw else 1 for kw in keywords if kw in lower)
        if score > 0:
            scores[ptype] = score

    sorted_types = sorted(scores.items(), key=lambda x: x[1], reverse=True)
    if not sorted_types or sorted_types[0][1] < 1:
        return {"projectType": "default", "blocks": DEFAULT_BLOCKS, "confidence": 0}

    best_type = sorted_types[0][0]
    confidence = min(sorted_types[0][1] / 10, 1.0)
    blocks = PROJECT_TYPE_BLOCK_MAP.get(best_type, DEFAULT_BLOCKS)
    return {"projectType": best_type, "blocks": blocks, "confidence": round(confidence, 2)}


def select_blocks(project_type: Optional[str], text: str) -> dict:
    """Sélectionne les blocs adaptatifs."""
    if project_type:
        normalized = project_type.lower().strip()
        blocks = PROJECT_TYPE_BLOCK_MAP.get(normalized, DEFAULT_BLOCKS)
        return {"projectType": normalized, "blocks": blocks, "confidence": 1.0}
    return detect_project_type(text)


def validate_blocks(blocks: list[str]) -> dict:
    """Vérifie qu'une liste de blocs est valide (A et H présents)."""
    errors = []
    for b in blocks:
        if b not in ALL_BLOCKS:
            errors.append(f"Bloc invalide: {b}")
    if "A" not in blocks:
        errors.append("Le bloc A (Resume Executif) est obligatoire")
    if "H" not in blocks:
        errors.append("Le bloc H (Recommandations) est obligatoire")
    return {"valid": len(errors) == 0, "errors": errors}


# ═══════════════════════════════════════════════════════════════════════════════
# KNOWLEDGE EXTRACTION
# ═══════════════════════════════════════════════════════════════════════════════

def extract_relevant_modules(module_numbers: list[str]) -> str:
    """Extrait les modules pertinents de la knowledge base."""
    lines = KNOWLEDGE_BASE.split("\n")
    modules = []
    current_module = []
    in_target = False

    for line in lines:
        match = re.match(r"^## MODULE (\d+)", line)
        if match:
            if in_target and current_module:
                modules.append("\n".join(current_module))
            in_target = match.group(1) in module_numbers
            current_module = [line]
            continue
        if in_target:
            current_module.append(line)

    if in_target and current_module:
        modules.append("\n".join(current_module))

    return "\n\n---\n\n".join(modules) if modules else KNOWLEDGE_BASE[:3000]


# ═══════════════════════════════════════════════════════════════════════════════
# CoT PROMPT BUILDER (équivalent de cot-prompts.ts)
# ═══════════════════════════════════════════════════════════════════════════════

def build_cot_prompt(
    step_number: int,
    step_name: str,
    user_input: str,
    previous_output: Optional[str],
    knowledge_content: str,
) -> str:
    """Construit le prompt complet pour une étape CoT."""
    modules = STEP_KNOWLEDGE_MODULES.get(step_name, ["0"])
    context = (
        f"\n## CONTEXTE ET CONNAISSANCES (Knowledge Base PEK v4.1)\n\n"
        f"Voici les modules pertinents pour cette etape ({', '.join(modules)}) :\n\n"
        f"{knowledge_content}\n\n---\n\n"
        f"Tu dois t'appuyer sur ces connaissances pour accomplir cette etape.\n"
    )
    prev = f"\n## RESULTAT DE L'ETAPE PRECEDENTE\n\n{previous_output}\n\n---\n" if previous_output else ""

    templates = {
        "comprendre": f"""{context}{prev}## {STEP_LABELS['comprendre']}

**Objectif** : Saisir globalement le projet fourni ci-dessous.

**Instructions** :
1. Lire l'integralite du materiel fourni
2. Identifier le type de projet (web, pipeline, agent IA, CLI, etc.)
3. Noter l'objectif principal en une phrase
4. Lister les contraintes majeures
5. Determiner le niveau de complexite (simple, moyen, complexe)
6. Identifier le format d'entree

**Format de sortie attendu** :
- **Type de projet** : [type detecte]
- **Objectif principal** : [une phrase]
- **Contraintes majeures** : [liste]
- **Niveau de complexite** : [simple/moyen/complex]
- **Format d'entree** : [format detecte]
- **Resume executif** : [3-5 phrases]

## MATERIEL A ANALYSER

{user_input}""",

        "decomposer": f"""{context}{prev}## {STEP_LABELS['decomposer']}

**Objectif** : Structurer mentalement le projet et determiner la structure de sortie adaptative.

**Instructions** :
1. Identifier les composants principaux
2. Cartographier les dependances
3. Repérer les patterns recurrents
4. Classer les informations par categorie
5. Determiner quels blocs de sortie (A-J) sont pertinents
6. Justifier chaque bloc selectionne et chaque bloc exclu

**Format de sortie attendu** :
- **Composants principaux** : [liste]
- **Dependances** : [carte]
- **Patterns identifies** : [liste]
- **Type de projet confirme** : [type]
- **Blocs de sortie selectionnes** : [liste A-J avec justification]
- **Blocs exclus et raison** : [liste]""",

        "extraire": f"""{context}{prev}## {STEP_LABELS['extraire']}

**Objectif** : Extraire systematiquement tous les elements pertinents du projet.

**Checklist** :
- Objectif principal + sous-objectifs
- Regles absolues + limitations techniques
- Etapes successives + decisions prises
- Format de sortie + blocs selectionnes
- Style + langue + niveau de detail
- Scripts + plateformes + bibliotheques
- Donnees d'entree (types, schemas)
- Donnees de sortie attendues""",

        "structurer": f"""{context}{prev}## {STEP_LABELS['structurer']}

**Objectif** : Organiser les elements extraits dans l'architecture du kit PEK.

**Instructions** :
1. Mapper chaque element au module correspondant (System, Role, Constraints, Context, Structure, Formatting, QualityControl, Reasoning)
2. Identifier les lacunes
3. Proposer une organisation optimale""",

        "generer": f"""{context}{prev}## {STEP_LABELS['generer']}

**Objectif** : Produire le contenu complet du Prompt Engineering Kit.

**Instructions** :
1. Generer chaque bloc selectionne a l'etape 2 dans l'ordre logique
2. Bloc A (Resume) en premier, bloc H (Recommandations) en dernier
3. Respecter le format et contenu specifies dans le MODULE 4
4. Appliquer les regles de formatting du MODULE 5""",

        "valider": f"""{context}{prev}## {STEP_LABELS['valider']}

**Objectif** : Verifier la qualite et la coherence du contenu genere.

Appliquer la checklist du MODULE 6 (QualityControl) :
- Pre-Generation (5 points)
- Post-Generation (10 points)
- Qualite (10 points)

**Format** : Score par categorie + total N/25 + statut""",

        "ameliorer": f"""{context}{prev}## {STEP_LABELS['ameliorer']}

**Objectif** : Proposer des evolutions et ameliorations.

**Instructions** :
1. Identifier 3 points d'amelioration prioritaires
2. Noter les cas limites non couverts
3. Suggerer des tests additionnels
4. Documenter les evolutions futures possibles""",
    }
    return templates.get(step_name, f"{context}\n{user_input}")


# ═══════════════════════════════════════════════════════════════════════════════
# VALIDATION (25 points — équivalent de validation.ts)
# ═══════════════════════════════════════════════════════════════════════════════

def validate_output(
    output: str,
    selected_blocks: Optional[list[str]],
    previous_outputs: Optional[list[str]],
) -> dict:
    """Évalue automatiquement la qualité (heuristiques). Retourne un dict complet."""
    text = output.lower()
    all_text = "\n".join(previous_outputs or []).lower() if previous_outputs else text

    def check(label: str, condition: bool, detail: str) -> dict:
        return {"label": label, "passed": condition, "detail": detail}

    # Pre-Generation (5 pts)
    pre = [
        check("Infos requises presentes", len(text) > 100,
              f"{len(text)} caracteres" if len(text) > 100 else "Trop court"),
        check("Contexte clair", any(w in text for w in ["objectif","contexte","projet"]),
              "Mots-cles trouves" if any(w in text for w in ["objectif","contexte","projet"]) else "Absents"),
        check("Contraintes definies", any(w in text for w in ["contrainte","regle","limitation"]),
              "Trouvees" if any(w in text for w in ["contrainte","regle","limitation"]) else "Absentes"),
        check("Format identifie", any(w in text for w in ["format",".md",".json","markdown"]),
              "Trouve" if any(w in text for w in ["format",".md",".json","markdown"]) else "Absent"),
        check("Exemples pertinents", any(w in text for w in ["exemple","ex ","cas d'usage"]),
              "Trouves" if any(w in text for w in ["exemple","ex ","cas d'usage"]) else "Absents"),
    ]
    pre_score = sum(1 for i in pre if i["passed"])

    # Post-Generation (10 pts)
    post = [
        check("Blocs presents", True, "Non applicable en mode heuristic"),
        check("Schemas valides", True, "Non applicable en mode heuristic"),
        check("Domaines varies", "exemple" in text, "Trouves" if "exemple" in text else "Absents"),
        check("Tests varies", any(w in text for w in ["test","validation","scenario"]),
              "Trouves" if any(w in text for w in ["test","validation","scenario"]) else "Absents"),
        check("Pas de placeholder", "[a completer]" not in text and "[todo]" not in text,
              "OK" if "[a completer]" not in text else "Placeholders"),
        check("Schemas definis", True, "Non applicable"),
        check("References valides", True, "Non applicable en mode API"),
        check("Version coherent", "v4.1" in text or "version" in text, "Trouve" if "v4.1" in text else "Absent"),
        check("Terminologie uniforme", "chain-of-thought" in all_text or "cot" in all_text, "Coherent"),
        check("Pas de contradictions", True, "Verification automatique limitee"),
    ]
    post_score = sum(1 for i in post if i["passed"])

    # Quality (10 pts)
    sentences = [s.strip() for s in text.split(".") if len(s.strip()) > 20]
    unique = len(set(sentences))
    quality = [
        check("Langage clair", len(text) > 200, "Substantiel" if len(text) > 200 else "Trop court"),
        check("Formatting", any(c in text for c in ["#","-","*"]), "Markdown" if any(c in text for c in ["#","-","*"]) else "Absent"),
        check("Syntaxe valide", True, "Non applicable"),
        check("Code fonctionnel", "error" not in text or "gestion des erreurs" in text, "OK"),
        check("Exemples concrets", any(w in text for w in ["exemple","cas","scenario"]), "Trouves"),
        check("Tests pertinents", "test" in text or "validation" in text, "Trouves"),
        check("Doc complete", len(text) > 300, "Substantielle" if len(text) > 300 else "Courte"),
        check("Coherence blocs", True, "Verification limitee"),
        check("Style coherent", "???" not in text and "!!!" not in text, "OK"),
        check("Pas de redondance", unique >= len(sentences) * 0.8 if sentences else True,
              f"{unique}/{len(sentences)} phrases uniques"),
    ]
    quality_score = sum(1 for i in quality if i["passed"])

    total = pre_score + post_score + quality_score
    if total >= 25:
        status = "PARFAIT"
    elif total >= 22:
        status = "EXCELLENT"
    elif total >= 20:
        status = "ACCEPTABLE"
    else:
        status = "A_REPRENDRE"

    return {
        "score": total, "maxScore": 25, "passed": total >= 22, "status": status,
        "details": {
            "preGeneration": {"score": pre_score, "max": 5, "items": pre},
            "postGeneration": {"score": post_score, "max": 10, "items": post},
            "quality": {"score": quality_score, "max": 10, "items": quality},
        },
    }


# ═══════════════════════════════════════════════════════════════════════════════
# RATE LIMITING
# ═══════════════════════════════════════════════════════════════════════════════

_rate_map: dict[str, dict] = {}

def with_rate_limit(f, limit=100, window_ms=60000):
    """Décorateur de rate limiting in-memory."""
    def wrapper(*args, **kwargs):
        ip = request.headers.get("x-forwarded-for", "local").split(",")[0].strip()
        now = time.time() * 1000
        rec = _rate_map.get(ip)
        if not rec or now > rec["reset"]:
            _rate_map[ip] = {"count": 1, "reset": now + window_ms}
        elif rec["count"] >= limit:
            return jsonify({"error": "Rate limit atteint"}), 429
        else:
            rec["count"] += 1
        return f(*args, **kwargs)
    wrapper.__name__ = f.__name__
    return wrapper


# ═══════════════════════════════════════════════════════════════════════════════
# API ROUTES (6 endpoints — équivalent des routes Next.js)
# ═══════════════════════════════════════════════════════════════════════════════

@app.route("/api/sessions", methods=["POST"])
@with_rate_limit
def create_session():
    """POST /api/sessions — Créer une nouvelle session."""
    try:
        data = CreateSessionInput(**request.get_json(silent=True) or {})
    except Exception as e:
        return jsonify({"error": f"Donnees invalides: {e}"}), 400

    db = get_db()
    sid = _generate_id()
    now = datetime.now(timezone.utc).isoformat()
    try:
        db.execute(
            "INSERT INTO Session (id, title, status, projectType, createdAt, updatedAt) VALUES (?,?,?,?,?,?)",
            (sid, data.title or "Nouvelle session PEK v4.1", "active", data.project_type, now, now),
        )
        db.commit()
    except Exception as e:
        return jsonify({"error": str(e)}), 400

    return jsonify({
        "id": sid, "title": data.title or "Nouvelle session PEK v4.1",
        "projectType": data.project_type, "status": "active",
        "createdAt": now, "message": "Session creee.",
        "nextStep": 1,
    }), 201


@app.route("/api/sessions/<session_id>", methods=["GET"])
@with_rate_limit
def get_session(session_id: str):
    """GET /api/sessions/:id — Récupérer une session avec ses étapes."""
    db = get_db()
    row = db.execute("SELECT * FROM Session WHERE id=?", (session_id,)).fetchone()
    if not row:
        return jsonify({"error": "Session non trouvee"}), 404

    steps = db.execute(
        "SELECT * FROM SessionStep WHERE sessionId=? ORDER BY step ASC", (session_id,)
    ).fetchall()

    completed = [s["step"] for s in steps]
    next_step = 1
    while next_step in completed and next_step <= 7:
        next_step += 1

    sel_blocks = None
    if row["selectedBlocks"]:
        try:
            sel_blocks = json.loads(row["selectedBlocks"])
        except Exception:
            pass

    return jsonify({
        "id": row["id"], "title": row["title"], "status": row["status"],
        "projectType": row["projectType"], "selectedBlocks": sel_blocks,
        "validationScore": row["validationScore"],
        "nextStep": next_step if next_step <= 7 else None,
        "completedSteps": completed, "totalSteps": 7,
        "steps": [{
            "id": s["id"], "step": s["step"], "stepName": s["stepName"],
            "outputPreview": s["output"][:200] + ("..." if len(s["output"]) > 200 else ""),
            "validationScore": s["validationScore"],
            "selectedBlocks": json.loads(s["selectedBlocks"]) if s["selectedBlocks"] else None,
            "createdAt": s["createdAt"],
        } for s in steps],
        "createdAt": row["createdAt"], "updatedAt": row["updatedAt"],
    })


@app.route("/api/sessions/<session_id>/execute", methods=["POST"])
@with_rate_limit
def execute_step(session_id: str):
    """POST /api/sessions/:id/execute — Exécuter une étape CoT."""
    db = get_db()

    # Vérifier session
    session = db.execute("SELECT * FROM Session WHERE id=?", (session_id,)).fetchone()
    if not session:
        return jsonify({"error": "Session non trouvee"}), 404

    # Valider le body
    try:
        data = ExecuteStepInput(**request.get_json(silent=True) or {})
    except Exception as e:
        return jsonify({"error": f"Donnees invalides: {e}"}), 400

    current_step = data.current_step
    step_name = data.step_name or STEP_NAME_FROM_NUMBER.get(current_step, "")
    if not step_name or step_name not in STEP_NAMES:
        return jsonify({"error": f"Nom d'etape invalide: {step_name}"}), 400

    # Contrôle séquentiel
    existing = db.execute(
        "SELECT * FROM SessionStep WHERE sessionId=? ORDER BY step ASC", (session_id,)
    ).fetchall()
    completed_steps = [s["step"] for s in existing]

    if current_step in completed_steps:
        return jsonify({"error": f"Etape {current_step} deja executee"}), 409
    if current_step > 1 and (current_step - 1) not in completed_steps:
        return jsonify({"error": f"L'etape {current_step-1} doit etre executee avant l'etape {current_step}"}), 400

    # Résoudre previousOutput depuis la DB
    prev_output = data.previous_output
    if not prev_output and current_step > 1:
        prev = db.execute(
            "SELECT output FROM SessionStep WHERE sessionId=? AND step=?",
            (session_id, current_step - 1),
        ).fetchone()
        if prev:
            prev_output = prev["output"]

    # Knowledge base (modules pertinents)
    module_nums = STEP_KNOWLEDGE_MODULES.get(step_name, ["0"])
    knowledge = extract_relevant_modules(module_nums)

    # Sélection des blocs (étape 2)
    selected_blocks = None
    detected_type = data.project_type or None

    if current_step == 2 or data.project_type:
        result = select_blocks(detected_type, data.user_input + (prev_output or ""))
        selected_blocks = result["blocks"]
        detected_type = result["projectType"]
        db.execute(
            "UPDATE Session SET projectType=?, selectedBlocks=? WHERE id=?",
            (detected_type, json.dumps(selected_blocks), session_id),
        )
        db.commit()
    elif data.selected_blocks:
        selected_blocks = data.selected_blocks
    elif session["selectedBlocks"]:
        try:
            selected_blocks = json.loads(session["selectedBlocks"])
        except Exception:
            selected_blocks = None

    # Construire le prompt et appeler le LLM
    full_prompt = build_cot_prompt(current_step, step_name, data.user_input, prev_output, knowledge)
    output = generate(full_prompt, step_name)

    # Validation (étape 6)
    validation_score = None
    validation_result = None
    if current_step == 6:
        all_outputs = [s["output"] for s in existing]
        validation_result = validate_output(output, selected_blocks, all_outputs)
        validation_score = validation_result["score"]
        db.execute(
            "UPDATE Session SET validationScore=? WHERE id=?",
            (validation_score, session_id),
        )
        db.commit()

    # Persister l'étape
    step_id = _generate_id()
    now = datetime.now(timezone.utc).isoformat()
    try:
        db.execute(
            """INSERT INTO SessionStep
               (id, sessionId, step, stepName, selectedBlocks, validationScore, projectType, input, output, createdAt)
               VALUES (?,?,?,?,?,?,?,?,?,?)""",
            (step_id, session_id, current_step, step_name,
             json.dumps(selected_blocks) if selected_blocks else None,
             validation_score, detected_type, data.user_input, output, now),
        )
        db.commit()
    except sqlite3.IntegrityError:
        return jsonify({"error": "Etape deja executee (conflit)"}), 409

    # Marquer complétée si étape 7
    if current_step == 7:
        db.execute("UPDATE Session SET status='completed', updatedAt=? WHERE id=?", (now, session_id))
        db.commit()

    resp = {
        "step": current_step, "stepName": step_name, "output": output,
        "selectedBlocks": selected_blocks, "projectType": detected_type,
        "validationScore": validation_score,
        "stepId": step_id,
        "nextStep": current_step + 1 if current_step < 7 else None,
    }
    if validation_result:
        resp["validationResult"] = validation_result
    return jsonify(resp)


@app.route("/api/sessions/<session_id>/export", methods=["GET"])
@with_rate_limit
def export_session(session_id: str):
    """GET /api/sessions/:id/export — Export Markdown structuré."""
    db = get_db()
    session = db.execute(
        "SELECT * FROM Session WHERE id=?", (session_id,)
    ).fetchone()
    if not session:
        return jsonify({"error": "Session non trouvee"}), 404

    steps = db.execute(
        "SELECT * FROM SessionStep WHERE sessionId=? ORDER BY step ASC", (session_id,)
    ).fetchall()

    # Blocs sélectionnés
    blocks = ["A", "H"]
    if session["selectedBlocks"]:
        try:
            blocks = json.loads(session["selectedBlocks"])
        except Exception:
            pass
    else:
        s2 = next((s for s in steps if s["step"] == 2), None)
        if s2 and s2["selectedBlocks"]:
            try:
                blocks = json.loads(s2["selectedBlocks"])
            except Exception:
                pass

    md = f"# {session['title']}\n\n"
    md += f"**PEK v{VERSION}** | Type : {session['projectType'] or 'non detecte'} | "
    md += f"Blocs : {', '.join(blocks)} | Score : {session['validationScore'] or 'N/A'}/25\n\n---\n\n"

    steps_by_num = {s["step"]: s for s in steps}
    for block in blocks:
        label = BLOCK_LABELS.get(block, block)
        md += f"## BLOC {block} : {label}\n\n"
        if block == "A" and 1 in steps_by_num:
            md += steps_by_num[1]["output"] + "\n"
        elif block == "B" and 2 in steps_by_num:
            md += steps_by_num[2]["output"] + "\n"
        elif block == "C" and 3 in steps_by_num:
            md += steps_by_num[3]["output"] + "\n"
        elif block == "D" and 4 in steps_by_num:
            md += steps_by_num[4]["output"] + "\n"
        elif block == "E" and 3 in steps_by_num:
            md += steps_by_num[3]["output"] + "\n"
        elif block == "F" and 5 in steps_by_num:
            md += steps_by_num[5]["output"] + "\n"
        elif block == "G":
            md += "1. Comprehension (Etape 1)\n2. Decomposition (Etape 2)\n3. Extraction (Etape 3)\n"
            md += "4. Structuration (Etape 4)\n5. Generation (Etape 5)\n6. Validation (Etape 6)\n7. Amelioration (Etape 7)\n"
        elif block == "H" and 7 in steps_by_num:
            md += steps_by_num[7]["output"] + "\n"
        elif block == "I" and 6 in steps_by_num:
            md += steps_by_num[6]["output"] + "\n"
        elif block == "J":
            md += "- **PEK** : Prompt Engineering Kit\n- **CoT** : Chain-of-Thought\n"
            md += f"- **Type** : {session['projectType'] or 'non detecte'}\n"
        else:
            md += "*Non genere*\n"
        md += "\n---\n\n"

    md += "## Historique complet des etapes\n\n"
    for s in steps:
        md += f"### Etape {s['step']} : {s['stepName']}\n\n{s['output']}\n\n---\n\n"

    return Response(md, mimetype="text/markdown; charset=utf-8",
                    headers={"Content-Disposition": f"attachment; filename=pek-v4.1-{session_id[:8]}.md"})


@app.route("/api/knowledge", methods=["GET"])
@with_rate_limit
def get_knowledge():
    """GET /api/knowledge — Knowledge base complète ou par module."""
    module_param = request.args.get("module")

    if module_param:
        module_num = str(module_param)
        valid = ["0","1","2","3","4","5","6","7"]
        if module_num not in valid:
            return jsonify({"error": f"Module {module_param} non trouve", "availableModules": valid}), 404
        content = extract_relevant_modules([module_num])
        return jsonify({"module": module_num, "content": content})

    module_count = len(re.findall(r"^## MODULE \d+", KNOWLEDGE_BASE, re.MULTILINE))
    return jsonify({"version": VERSION, "moduleCount": module_count, "content": KNOWLEDGE_BASE})


@app.route("/api/debug", methods=["GET"])
def debug():
    """GET /api/debug — Health check."""
    return jsonify({
        "version": VERSION, "status": "ok", "provider": "python",
        "modules": 8, "steps": 7, "blocks": "A-J",
        "validationMaxScore": 25, "llm_provider": LLM_PROVIDER,
        "db_path": DB_PATH,
    })


# ═══════════════════════════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    import sys

    if "--init-db" in sys.argv:
        init_db()
        sys.exit(0)

    port = 5000
    for arg in sys.argv:
        if arg.startswith("--port="):
            port = int(arg.split("=")[1])

    init_db()
    print(f"\n{'='*60}")
    print(f"  PEK v{VERSION} — Monolithe Python")
    print(f"  Flask + sqlite3 + Pydantic")
    print(f"  LLM Provider : {LLM_PROVIDER}")
    print(f"  DB : {DB_PATH}")
    print(f"  http://localhost:{port}")
    print(f"{'='*60}\n")
    app.run(host="0.0.0.0", port=port, debug=False)