/**
 * adaptive-blocks.ts — Logique de sélection des blocs adaptatifs A-J
 * Matrice type-projet → blocs, détection automatique, sélecteur
 */

export const ALL_BLOCKS = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J'] as const;
export type Block = (typeof ALL_BLOCKS)[number];

export const BLOCK_LABELS: Record<Block, string> = {
  A: 'Resume Executif',
  B: 'Architecture & Composants',
  C: 'Prompt / Instructions Principales',
  D: 'Donnees & Schemas',
  E: 'Contraintes & Regles',
  F: 'Resultats & Outputs',
  G: 'Guide d\'Utilisation',
  H: 'Recommandations & Ameliorations',
  I: 'Tests & Validation',
  J: 'Glossaire & References',
};

export const BLOCK_DESCRIPTIONS: Record<Block, string> = {
  A: 'Objectif du projet, contexte, livrables principaux (paragraphe structure 3-5 phrases)',
  B: 'Diagramme des composants, dependances, flux de donnees (arborescence textuelle)',
  C: 'Prompts systeme, instructions de traitement, regles metier (blocs de code/XML)',
  D: 'Schemas d\'entree/sortie, formats attendus, exemples de donnees (tableaux, JSON/YAML)',
  E: 'Limitations techniques, regles metier, invariants (liste avec criticite)',
  F: 'Outputs produits, metriques, artefacts generes (liste avec descriptions)',
  G: 'Instructions pas-a-pas pour reproduire ou utiliser le projet (etapes numerotees)',
  H: 'Axes d\'amelioration, optimisations, evolutions futures (liste priorisee)',
  I: 'Cas de test, scenarios de validation, criteres de succes (tableau input/attendu/criteres)',
  J: 'Termes techniques, liens utiles, dependances externes (tableau ou liste)',
};

// Matrice type-projet → blocs sélectionnés (issue de v3.1 04_Structure.md)
export const PROJECT_TYPE_BLOCK_MAP: Record<string, Block[]> = {
  web:              ['A', 'B', 'C', 'D', 'E', 'G', 'H', 'I'],
  'pipeline-data':  ['A', 'B', 'D', 'E', 'F', 'G', 'H', 'I'],
  'etl':            ['A', 'B', 'D', 'E', 'F', 'G', 'H', 'I'],
  'agent-ia':       ['A', 'C', 'D', 'E', 'G', 'H', 'J'],
  'chatbot':        ['A', 'C', 'D', 'E', 'G', 'H', 'J'],
  'analyse-donnees':['A', 'D', 'F', 'H', 'J'],
  'rapport':        ['A', 'D', 'F', 'H', 'J'],
  'systeme-embarque':['A', 'B', 'D', 'E', 'G', 'H', 'I'],
  'iot':            ['A', 'B', 'D', 'E', 'G', 'H', 'I'],
  'cli':            ['A', 'C', 'E', 'G', 'H', 'I'],
  'script':         ['A', 'C', 'E', 'G', 'H', 'I'],
  'devops':         ['A', 'B', 'C', 'E', 'G', 'H', 'I'],
  'infrastructure': ['A', 'B', 'C', 'E', 'G', 'H', 'I'],
  'mobile':         ['A', 'B', 'C', 'D', 'E', 'G', 'H', 'I'],
  'api':            ['A', 'B', 'D', 'E', 'F', 'H', 'I'],
  'microservice':   ['A', 'B', 'D', 'E', 'F', 'H', 'I'],
};

// Blocs par défaut si le type n'est pas reconnu
export const DEFAULT_BLOCKS: Block[] = ['A', 'C', 'E', 'G', 'H'];

// Mots-clés de détection par type de projet
const KEYWORDS_MAP: Record<string, string[]> = {
  web:              ['next.js', 'react', 'vue', 'angular', 'svelte', 'frontend', 'html', 'css', 'tailwind', 'page web', 'interface'],
  'pipeline-data':  ['pipeline', 'etl', 'elt', 'airflow', 'dagster', 'prefect', 'data pipeline', 'batch', 'streaming'],
  'agent-ia':       ['agent', 'ia', 'ai', 'llm', 'langchain', 'rag', 'embedding', 'prompt', 'gpt', 'claude', 'mistral'],
  'chatbot':        ['chatbot', 'conversationnel', 'dialogue', 'support client', 'faq', 'assistant virtuel'],
  'analyse-donnees':['analyse', 'data', 'dataset', 'pandas', 'numpy', 'jupyter', 'notebook', 'statistique', 'visualisation'],
  'cli':            ['cli', 'command line', 'terminal', 'outil en ligne de commande', 'shell script', 'bash'],
  'devops':         ['devops', 'docker', 'kubernetes', 'ci/cd', 'github actions', 'terraform', 'ansible', 'infrastructure as code'],
  'mobile':         ['mobile', 'react native', 'flutter', 'ios', 'android', 'app mobile'],
  'api':            ['api', 'rest', 'graphql', 'endpoint', 'microservice', 'backend', 'express', 'fastapi', 'nest'],
};

/**
 * Détecte automatiquement le type de projet à partir du texte fourni.
 * Retourne le type de projet et les blocs sélectionnés.
 */
export function detectProjectType(text: string): { projectType: string; blocks: Block[]; confidence: number } {
  const lower = text.toLowerCase();
  const scores: Record<string, number> = {};

  for (const [type, keywords] of Object.entries(KEYWORDS_MAP)) {
    let score = 0;
    for (const kw of keywords) {
      if (lower.includes(kw)) {
        score += kw.includes(' ') ? 2 : 1; // Mots composés = plus de poids
      }
    }
    if (score > 0) scores[type] = score;
  }

  // Trouver le type avec le score le plus élevé
  const sorted = Object.entries(scores).sort(([, a], [, b]) => b - a);

  if (sorted.length === 0 || sorted[0][1] < 1) {
    return { projectType: 'default', blocks: DEFAULT_BLOCKS, confidence: 0 };
  }

  const bestType = sorted[0][0];
  const bestScore = sorted[0][1];
  const confidence = Math.min(bestScore / 10, 1);

  // Si le type détecté a une entrée dans la matrice, l'utiliser
  const blocks = PROJECT_TYPE_BLOCK_MAP[bestType] || DEFAULT_BLOCKS;

  return { projectType: bestType, blocks, confidence: Math.round(confidence * 100) / 100 };
}

/**
 * Sélectionne les blocs adaptatifs. Si projectType est fourni, utilise la matrice.
 * Sinon, tente la détection automatique depuis le texte.
 */
export function selectBlocks(
  projectType: string | null | undefined,
  text: string
): { blocks: Block[]; projectType: string; confidence: number } {
  if (projectType) {
    const normalized = projectType.toLowerCase().trim();
    const mapped = PROJECT_TYPE_BLOCK_MAP[normalized] || DEFAULT_BLOCKS;
    return { blocks: mapped, projectType: normalized, confidence: 1 };
  }

  return detectProjectType(text);
}

/**
 * Vérifie qu'une liste de blocs est valide (contient A et H, tout le monde est dans A-J)
 */
export function validateBlocks(blocks: string[]): { valid: boolean; errors: string[] } {
  const errors: string[] = [];
  const validBlocks = new Set(ALL_BLOCKS);

  for (const b of blocks) {
    if (!validBlocks.has(b as Block)) {
      errors.push(`Bloc invalide: ${b}`);
    }
  }

  if (!blocks.includes('A')) {
    errors.push('Le bloc A (Resume Executif) est obligatoire');
  }
  if (!blocks.includes('H')) {
    errors.push('Le bloc H (Recommandations) est obligatoire');
  }

  return { valid: errors.length === 0, errors };
}