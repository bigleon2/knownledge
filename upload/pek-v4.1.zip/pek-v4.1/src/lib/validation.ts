/**
 * validation.ts — Système de validation qualité (25 points)
 * Implémente les 3 checklists de 06_QualityControl de v3.1
 */

export interface ValidationResult {
  score: number;
  maxScore: number;
  passed: boolean;
  status: 'PARFAIT' | 'EXCELLENT' | 'ACCEPTABLE' | 'A_REPRENDRE';
  details: {
    preGeneration: ChecklistResult;
    postGeneration: ChecklistResult;
    quality: ChecklistResult;
  };
}

interface ChecklistResult {
  score: number;
  max: number;
  items: ChecklistItem[];
}

interface ChecklistItem {
  label: string;
  passed: boolean;
  detail?: string;
}

const MINIMUM_SCORE = 22;
const PARFAIT = 25;
const EXCELLENT_MIN = 22;
const ACCEPTABLE_MIN = 20;

// --- Checklists ---

const PRE_GENERATION_CHECKLIST: ChecklistItem[] = [
  { label: 'Toutes les informations requises sont presentes', passed: false },
  { label: 'Le contexte est clair et complet', passed: false },
  { label: 'Les contraintes sont bien definies et non contradictoires', passed: false },
  { label: 'Le format d\'entree est identifie', passed: false },
  { label: 'Les exemples sont pertinents et diversifies', passed: false },
];

const POST_GENERATION_CHECKLIST: ChecklistItem[] = [
  { label: 'Tous les blocs selectionnes sont presents et complets', passed: false },
  { label: 'Les schemas sont valides', passed: false },
  { label: 'Les exemples sont de domaines varies', passed: false },
  { label: 'Tests avec scenarios varies', passed: false },
  { label: 'Aucun contenu vide sans notification', passed: false },
  { label: 'Tous les schemas definis', passed: false },
  { label: 'References croisees valides', passed: false },
  { label: 'Versionning coherent', passed: false },
  { label: 'Terminologie uniforme', passed: false },
  { label: 'Pas de contradictions entre blocs', passed: false },
];

const QUALITY_CHECKLIST: ChecklistItem[] = [
  { label: 'Langage clair et sans ambiguite', passed: false },
  { label: 'Formatting correct', passed: false },
  { label: 'Syntaxe valide', passed: false },
  { label: 'Code fonctionnel (si applicable)', passed: false },
  { label: 'Exemples concrets et realistes', passed: false },
  { label: 'Tests pertinents', passed: false },
  { label: 'Documentation complete', passed: false },
  { label: 'Coherence entre blocs', passed: false },
  { label: 'Style coherent', passed: false },
  { label: 'Pas de redondance', passed: false },
];

/**
 * Évalue automatiquement la qualité du contenu généré.
 * Effectue des vérifications par heuristiques sur le texte.
 */
export function validate(
  output: string,
  selectedBlocks: string[] | null,
  previousStepsOutputs: string[] | null
): ValidationResult {
  const text = output.toLowerCase();
  const allOutputs = previousStepsOutputs ? previousStepsOutputs.join('\n').toLowerCase() : text;

  // --- Pre-Generation (5 points) ---
  const preGen = PRE_GENERATION_CHECKLIST.map((item) => {
    let passed = false;
    let detail: string | undefined;

    switch (item.label) {
      case 'Toutes les informations requises sont presentes':
        passed = text.length > 100;
        detail = passed ? `${text.length} caracteres detectes` : 'Contenu trop court (< 100 chars)';
        break;
      case 'Le contexte est clair et complet':
        passed = text.includes('objectif') || text.includes('contexte') || text.includes('projet');
        detail = passed ? 'Mots-cles de contexte trouves' : 'Aucun mot-cle de contexte';
        break;
      case 'Les contraintes sont bien definies et non contradictoires':
        passed = text.includes('contrainte') || text.includes('regle') || text.includes('limitation');
        detail = passed ? 'Contraintes identifiees' : 'Aucune contrainte mentionnee';
        break;
      case 'Le format d\'entree est identifie':
        passed = text.includes('format') || text.includes('.md') || text.includes('.json') || text.includes('markdown');
        detail = passed ? 'Format identifie' : 'Format non mentionne';
        break;
      case 'Les exemples sont pertinents et diversifies':
        passed = text.includes('exemple') || text.includes('ex ') || text.includes('cas d\'usage');
        detail = passed ? 'Exemples trouves' : 'Aucun exemple';
        break;
    }

    return { ...item, passed, detail };
  });

  // --- Post-Generation (10 points) ---
  const postGen = POST_GENERATION_CHECKLIST.map((item) => {
    let passed = false;
    let detail: string | undefined;

    switch (item.label) {
      case 'Tous les blocs selectionnes sont presents et complets':
        if (selectedBlocks) {
          const missing = selectedBlocks.filter(b => !allOutputs.includes(`bloc ${b.toLowerCase()}`) && !allOutputs.includes(`bloc ${b}`));
          passed = missing.length === 0;
          detail = passed ? 'Tous les blocs presents' : `Blocs manquants: ${missing.join(', ')}`;
        } else {
          passed = true; // Pas de sélection = pas de vérification
          detail = 'Aucun bloc specifie, verification non applicable';
        }
        break;
      case 'Les schemas sont valides':
        passed = true; // N/A en mode mock
        detail = 'Verification schema non applicable en mode mock';
        break;
      case 'Les exemples sont de domaines varies':
        passed = text.includes('exemple');
        detail = passed ? 'Exemples presents' : 'Aucun exemple';
        break;
      case 'Tests avec scenarios varies':
        passed = text.includes('test') || text.includes('validation') || text.includes('scenario');
        detail = passed ? 'Tests/scenarios mentionnes' : 'Aucun test';
        break;
      case 'Aucun contenu vide sans notification':
        passed = !text.includes('[a completer]') && !text.includes('[todo]');
        detail = passed ? 'Aucun placeholder' : 'Placeholders detectes';
        break;
      case 'Tous les schemas definis':
        passed = true;
        detail = 'Verification schema non applicable en mode mock';
        break;
      case 'References croisees valides':
        passed = true;
        detail = 'Pas de fichiers croises en mode API';
        break;
      case 'Versionning coherent':
        passed = text.includes('v4.1') || text.includes('version');
        detail = passed ? 'Version mentionnee' : 'Version non mentionnee';
        break;
      case 'Terminologie uniforme':
        // Vérifier qu'il n'y a pas de mélange incohérent de termes
        const termCount = (allOutputs.match(/chain-of-thought/g) || []).length +
                          (allOutputs.match(/cot/g) || []).length;
        passed = termCount > 0;
        detail = passed ? 'Terminologie CoT coherente' : 'Terminologie non verifiee';
        break;
      case 'Pas de contradictions entre blocs':
        passed = true; // Difficile à vérifier automatiquement
        detail = 'Verification automatique limitee';
        break;
    }

    return { ...item, passed, detail };
  });

  // --- Quality (10 points) ---
  const quality = QUALITY_CHECKLIST.map((item) => {
    let passed = false;
    let detail: string | undefined;

    switch (item.label) {
      case 'Langage clair et sans ambiguite':
        passed = text.length > 200;
        detail = passed ? 'Contenu substantiel' : 'Contenu trop court pour evaluer';
        break;
      case 'Formatting correct':
        passed = text.includes('#') || text.includes('-') || text.includes('*');
        detail = passed ? 'Markdown structure detecte' : 'Pas de formatage detecte';
        break;
      case 'Syntaxe valide':
        passed = true;
        detail = 'Pas de syntaxe a valider en mode texte';
        break;
      case 'Code fonctionnel (si applicable)':
        passed = !text.includes('error') || text.includes('gestion des erreurs');
        detail = passed ? 'Pas d\'erreur detectee ou geree' : 'Erreurs non gerees';
        break;
      case 'Exemples concrets et realistes':
        passed = text.includes('exemple') || text.includes('cas') || text.includes('scenario');
        detail = passed ? 'Exemples/cas trouves' : 'Aucun exemple concret';
        break;
      case 'Tests pertinents':
        passed = text.includes('test') || text.includes('validation');
        detail = passed ? 'Tests mentionnes' : 'Aucun test';
        break;
      case 'Documentation complete':
        passed = text.length > 300;
        detail = passed ? 'Documentation substantielle' : 'Documentation trop courte';
        break;
      case 'Coherence entre blocs':
        passed = true;
        detail = 'Verification automatique limitee';
        break;
      case 'Style coherent':
        passed = !text.includes('???') && !text.includes('!!!');
        detail = passed ? 'Style coherent' : 'Caracteres suspects detectes';
        break;
      case 'Pas de redondance':
        // Vérification simple : pas de phrases répétées
        const sentences = text.split('.').filter(s => s.trim().length > 20);
        const uniqueSentences = new Set(sentences.map(s => s.trim()));
        passed = uniqueSentences.size >= sentences.length * 0.8;
        detail = passed ? `${uniqueSentences.size}/${sentences.length} phrases uniques` : 'Redondance detectee';
        break;
    }

    return { ...item, passed, detail };
  });

  // --- Calcul du score ---
  const preScore = preGen.filter(i => i.passed).length;
  const postScore = postGen.filter(i => i.passed).length;
  const qualityScore = quality.filter(i => i.passed).length;
  const totalScore = preScore + postScore + qualityScore;

  let status: ValidationResult['status'];
  if (totalScore >= PARFAIT) status = 'PARFAIT';
  else if (totalScore >= EXCELLENT_MIN) status = 'EXCELLENT';
  else if (totalScore >= ACCEPTABLE_MIN) status = 'ACCEPTABLE';
  else status = 'A_REPRENDRE';

  return {
    score: totalScore,
    maxScore: 25,
    passed: totalScore >= MINIMUM_SCORE,
    status,
    details: {
      preGeneration: { score: preScore, max: 5, items: preGen },
      postGeneration: { score: postScore, max: 10, items: postGen },
      quality: { score: qualityScore, max: 10, items: quality },
    },
  };
}