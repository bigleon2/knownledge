/**
 * validators.ts — Schémas Zod pour la validation des requêtes
 * v4.1 : 7 étapes sémantiques CoT + blocs adaptatifs A-J
 */
import { z } from 'zod';

export const StepNameSchema = z.enum([
  'comprendre',
  'decomposer',
  'extraire',
  'structurer',
  'generer',
  'valider',
  'ameliorer',
]);

export type StepName = z.infer<typeof StepNameSchema>;

// Step number 1-7 correspondant aux noms
export const STEP_NUMBER_MAP: Record<StepName, number> = {
  comprendre: 1,
  decomposer: 2,
  extraire: 3,
  structurer: 4,
  generer: 5,
  valider: 6,
  ameliorer: 7,
};

export const STEP_NAME_FROM_NUMBER: Record<number, StepName> = {
  1: 'comprendre',
  2: 'decomposer',
  3: 'extraire',
  4: 'structurer',
  5: 'generer',
  6: 'valider',
  7: 'ameliorer',
};

// Blocs valides A-J
export const BLOCK_SCHEMA = z.enum(['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J']);

// Validation de la création de session
export const CreateSessionSchema = z.object({
  title: z.string().max(200).optional(),
  projectType: z.string().max(50).optional(),
});

// Validation de l'exécution d'une étape CoT
export const ExecuteStepSchema = z.object({
  currentStep: z.number().int().min(1).max(7),
  stepName: StepNameSchema.optional(),
  userInput: z.string().min(1).max(50000),
  previousOutput: z.string().max(100000).optional(),
  projectType: z.string().max(50).optional(),
  selectedBlocks: z.array(BLOCK_SCHEMA).max(10).min(2).optional(),
});

// Validation de l'ID session (CUID)
export const SessionIdSchema = z.string().cuid('ID de session invalide');

// Type dérivé
export type CreateSessionInput = z.infer<typeof CreateSessionSchema>;
export type ExecuteStepInput = z.infer<typeof ExecuteStepSchema>;