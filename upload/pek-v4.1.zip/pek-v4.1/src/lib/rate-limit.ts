import { NextResponse } from 'next/server';

const map = new Map<string, { count: number; reset: number }>();

type HandlerResult = NextResponse | Response;

export function withRateLimit<T>(
  handler: (req: Request, ctx: T) => Promise<HandlerResult>,
  limit = 100,
  windowMs = 60000
) {
  return async (req: Request, ctx: T): Promise<HandlerResult> => {
    const ip = req.headers.get('x-forwarded-for') || 'local';
    const now = Date.now();
    const rec = map.get(ip);

    if (!rec || now > rec.reset) {
      map.set(ip, { count: 1, reset: now + windowMs });
    } else if (rec.count >= limit) {
      return NextResponse.json({ error: 'Rate limit atteint' }, { status: 429 });
    } else {
      rec.count++;
    }

    return handler(req, ctx);
  };
}