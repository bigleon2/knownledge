/**
 * llm.ts — Module LLM pour PEK v4.1
 * En mode mock (LLM_PROVIDER=mock), simule des réponses riches par étape.
 * En mode production, envoie le prompt complet au LLM configuré.
 */

export async function generate(fullPrompt: string, stepName?: string): Promise<string> {
  const provider = process.env.LLM_PROVIDER || 'mock';

  if (provider === 'mock') {
    return generateMockResponse(fullPrompt, stepName);
  }

  // Mode production : appel réel au LLM
  return generateRealResponse(fullPrompt);
}

// --- Mock contextualisé par étape ---

function generateMockResponse(prompt: string, stepName?: string): string {
  const lower = prompt.toLowerCase();

  // Détecter le nom de l'étape depuis le prompt si non fourni
  if (!stepName) {
    if (lower.includes('etape 1') || lower.includes('comprehension')) stepName = 'comprendre';
    else if (lower.includes('etape 2') || lower.includes('decomposition')) stepName = 'decomposer';
    else if (lower.includes('etape 3') || lower.includes('extraction')) stepName = 'extraire';
    else if (lower.includes('etape 4') || lower.includes('structuration')) stepName = 'structurer';
    else if (lower.includes('etape 5') || lower.includes('generation')) stepName = 'generer';
    else if (lower.includes('etape 6') || lower.includes('validation')) stepName = 'valider';
    else if (lower.includes('etape 7') || lower.includes('amelioration')) stepName = 'ameliorer';
    else stepName = 'comprendre';
  }

  switch (stepName) {
    case 'comprendre':
      return `## Resultat - Etape 1 : Comprehension

**Type de projet** : Detecte depuis le materiel fourni

**Objectif principal** : Analyse complete du projet fourni par l'utilisateur, extraction des elements cles et generation d'un Prompt Engineering Kit structure.

**Contraintes majeures** :
- Respecter le Chain-of-Thought en 7 etapes
- Utiliser les blocs adaptatifs A-J selon le type de projet
- Valider avec le systeme de scoring 25 points
- Preserver le contenu original sans denaturation

**Niveau de complexite** : Moyen a eleve (projet multi-composants)

**Format d'entree** : Texte brut / Markdown

**Resume executif** :
Le projet presente un systeme d'ingenierie de prompts modulaire base sur une architecture en 7 etapes Chain-of-Thought. Le systeme utilise une base de connaissances de 8 modules (System, Role, Constraints, Context, Structure, Formatting, QualityControl, Reasoning) et des blocs de sortie adaptatifs (A-J) selectionnes dynamiquement selon le type de projet detecte. L'objectif est de convertir n'importe quel projet IA en un kit de prompt engineering complet et structure.`;

    case 'decomposer':
      return `## Resultat - Etape 2 : Decomposition

**Composants principaux** :
1. **Base de connaissances** : 8 modules methodologiques
2. **Moteur CoT** : 7 etapes sequentielles
3. **Systeme de blocs** : Selection adaptative A-J
4. **Module de validation** : Scoring 25 points, 3 checklists
5. **Systeme de persistance** : SQLite via Prisma ORM
6. **API REST** : 6 endpoints Next.js App Router
7. **Interface utilisateur** : Progression 7 etapes

**Dependances** :
- Base de connaissances --> Moteur CoT (injection contextuelle)
- Moteur CoT --> Blocs adaptatifs (selection a l'etape 2)
- Blocs adaptatifs --> Validation (verification coherence)
- Validation --> Export (rapport de score)

**Patterns identifies** :
- Architecture modulaire (SRP)
- Injection de dependances par modules de knowledge
- Pipeline sequentiel avec sorties verifiees
- Selection dynamique par type de projet

**Type de projet confirme** : web (application fullstack)

**Blocs de sortie selectionnes** :
- **A (Resume Executif)** : Obligatoire - toujours present
- **B (Architecture & Composants)** : Pertinent - projet logiciel multi-composants
- **C (Prompt / Instructions)** : Pertinent - le coeur du projet est un systeme de prompts
- **D (Donnees & Schemas)** : Pertinent - schemas d'entree/sortie, schemas Prisma
- **E (Contraintes & Regles)** : Pertinent - regles de validation, contraintes techniques
- **G (Guide d'Utilisation)** : Pertinent - utilisateur doit savoir utiliser l'API
- **H (Recommandations)** : Obligatoire - toujours present
- **I (Tests & Validation)** : Pertinent - systeme de scoring et cas de test

**Blocs exclus** :
- **F (Resultats & Outputs)** : Non pertinent - pas de donnees de sortie tangibles
- **J (Glossaire)** : Non pertinent - termes techniques deja expliques dans les blocs`;

    case 'extraire':
      return `## Resultat - Etape 3 : Extraction

**Objectif principal** : Convertir des projets IA en kits de prompt engineering structures

**Sous-objectifs** :
- Analyser le projet fourni (comprehension globale)
- Decomposer en composants (structuration)
- Generer les artefacts du kit (8 modules + blocs A-J)
- Valider la qualite (scoring 25 points)
- Proposer des ameliorations

**Regles absolues** :
- Preserver l'original (ne pas inventer)
- Completesse des fichiers
- Coherence des references
- Respect des schemas
- Application du CoT (7 etapes, pas de saut)
- Qualite des exemples (concrets, multi-domaine)

**Etapes successives** :
1. Comprehension globale du projet
2. Decomposition et selection de blocs A-J
3. Extraction systematique des elements
4. Structuration dans l'architecture 8 modules
5. Generation des artefacts
6. Validation (score 25 points)
7. Amelioration et recommandations

**Format de sortie** : Blocs adaptatifs A-J, structure par type de projet

**Style** : Professionnel et pedagogique, francais, markdown

**Technologies** : Next.js 15.1.3, React 19, Prisma, SQLite, Zod, TypeScript 5.7

**Donnees d'entree** :
- Type 1 : Texte brut / description de projet (string, max 50000 chars)
- Type 2 : Code source (analyse statique)
- Type 3 : Conversations exportees (markdown)`;

    case 'structurer':
      return `## Resultat - Etape 4 : Structuration

**Module System (comportement general)** :
- Mode de fonctionnement methodique et structure
- Principes : qualite > vitesse, CoT systematique, validation avant continuation
- Gestion des erreurs : clarification, alerte, options multiples
- Auto-verification avant chaque reponse

**Module Role (identite)** :
- Architecte en Prompt Engineering
- Competences : analyse de projets, architecture logicielle, prompt engineering, pedagogie, qualite
- Mission : conversion de projets en kits structures

**Module Constraints (regles absolues)** :
- 6 regles : preservation original, completesse, coherence references, respect schemas, CoT, qualite exemples
- 3 cas limites : projet incomplet, contradictions, ambiguite

**Module Context (cadre projet)** :
- 10 formats d'entree supportes (archive, markdown, code, etc.)
- Environnement technique v4.1

**Module Structure (blocs A-J)** :
- 10 blocs, hierarchie 3 niveaux
- Matrice 16 types de projets
- 5 regles de composition

**Module Formatting (style)** :
- Professionnel, pedagogique, paragraphs 2-4 phrases
- 7 interdictions strictes

**Module QualityControl (validation)** :
- 3 checklists : pre-gen (5pts), post-gen (10pts), qualite (10pts)
- Score min : 22/25, 4 niveaux de statut
- 7 pieges a eviter

**Module Reasoning (CoT)** :
- 7 etapes avec livrables specifiques
- Pipeline sequentiel avec sorties verifiees

**Lacunes identifiees** :
- Aucune lacune majeure. L'architecture couvre l'ensemble du domaine.`;

    case 'generer':
      return `## BLOC A : Resume Executif

Le PEK v4.1 est un kit de prompt engineering modulaire qui combine une plateforme Next.js 15 avec une methodologie en 7 etapes Chain-of-Thought. Le systeme accepte tout type de projet IA en entree, le decompose systematiquement, et produit un output structure avec des blocs adaptatifs selectionnes dynamiquement selon le type de projet detecte.

## BLOC B : Architecture & Composants

\`\`\`
pek-v4.1/
  prisma/schema.prisma       # Modeles Session + SessionStep (7 etapes)
  KNOWLEDGE.md               # 8 modules de connaissances
  src/
    lib/
      cot-prompts.ts         # 7 prompts CoT complets
      adaptive-blocks.ts     # Selection A-J + detection auto
      validation.ts          # Scoring 25 points
      validators.ts          # Zod schemas (7 etapes)
      llm.ts                 # Bridge LLM (mock/production)
      db.ts                  # Prisma singleton
      rate-limit.ts          # Rate limiter in-memory
    app/
      api/
        sessions/            # POST creation, GET session+steps
        sessions/[id]/
          execute/           # POST etape CoT
          export/            # GET markdown structure
        knowledge/           # GET knowledge base
      page.tsx               # UI 7 etapes
      layout.tsx             # Layout racine
\`\`\`

## BLOC C : Prompt / Instructions Principales

Le coeur du systeme est la fonction buildCoTPrompt() qui construit le prompt complet pour chaque etape en injectant les modules de knowledge pertinents. Par exemple, l'etape 1 (Comprehension) recoit les modules 0, 1 et 3 (System, Role, Context), tandis que l'etape 6 (Validation) recoit les modules 0, 2 et 6 (System, Constraints, QualityControl).

## BLOC D : Donnees & Schemas

**Schema Prisma Session** : id (CUID), title, status, projectType, selectedBlocks (JSON), validationScore, timestamps

**Schema Prisma SessionStep** : id, sessionId (FK), step (1-7), stepName, input, output, selectedBlocks, validationScore, projectType, createdAt

**Schema Zod ExecuteStep** : currentStep (1-7), stepName (enum), userInput (string max 50k), previousOutput (optional), projectType (optional), selectedBlocks (array A-J)

## BLOC E : Contraintes & Regles

- Le Chain-of-Thought doit etre suivi sequentiellement (1-7, pas de saut)
- Les blocs A (Resume) et H (Recommandations) sont obligatoires
- Le score de validation minimum est 22/25
- Le format d'entree est detecte automatiquement
- La base de connaissances est injectee selectivement par etape

## BLOC G : Guide d'Utilisation

1. Creer une session : POST /api/sessions avec {title}
2. Executer l'etape 1 : POST /api/sessions/{id}/execute avec {currentStep: 1, userInput: "..."}
3. Continuer les etapes 2-7 en passant le previousOutput de l'etape precedente
4. L'etape 2 detecte automatiquement le type de projet et selectionne les blocs A-J
5. L'etape 6 valide la qualite et retourne un score sur 25
6. Exporter le resultat : GET /api/sessions/{id}/export

## BLOC H : Recommandations & Ameliorations

1. **Integration LLM reel** : Remplacer le mock par un appel a l'API OpenAI, Claude ou Mistral pour des reponses contextuellement riches
2. **Streaming** : Implementer le streaming des reponses LLM pour une meilleure UX sur les etapes longues (5 et 7)
3. **Authentification** : Ajouter un systeme d'authentification pour proteger les sessions
4. **Historique** : Permettre la reprise d'une session a une etape intermediaire
5. **Multi-utilisateurs** : Etendre le schema Prisma pour supporter plusieurs utilisateurs avec des sessions isolees`;

    case 'valider':
      return `## Resultat - Etape 6 : Validation

### Checklist Pre-Generation (5 points)
- [x] Toutes les informations requises sont presentes : **1/1** - Contenu complet detecte
- [x] Le contexte est clair et complet : **1/1** - Objectifs et contexte identifies
- [x] Les contraintes sont bien definies : **1/1** - 6 regles absolues identifiees
- [x] Le format d'entree est identifie : **1/1** - Texte brut / Markdown
- [x] Les exemples sont pertinents : **1/1** - Exemples multi-domaine (ETL, RAG, CLI)

**Sous-total Pre-Generation : 5/5**

### Checklist Post-Generation (10 points)
- [x] Tous les blocs selectionnes sont presents et complets : **1/1** - A, B, C, D, E, G, H generes
- [x] Les schemas sont valides : **1/1** - Prisma + Zod conformes
- [x] Exemples de domaines varies : **1/1** - Plusieurs domaines couverts
- [ ] Tests avec scenarios varies : **0/1** - Tests manuels a completer
- [x] Aucun contenu vide : **1/1** - Tous les blocs ont du contenu
- [x] Tous les schemas definis : **1/1** - Prisma + Zod + blocs A-J
- [x] References croisees valides : **1/1** - Imports coherents
- [x] Versionning coherent : **1/1** - v4.1.0 partout
- [x] Terminologie uniforme : **1/1** - CoT, blocs, modules
- [x] Pas de contradictions entre blocs : **1/1** - Coherence verifiee

**Sous-total Post-Generation : 9/10**

### Checklist Qualite (10 points)
- [x] Langage clair : **1/1** - Professionnel et pedagogique
- [x] Formatting correct : **1/1** - Markdown structure
- [x] Syntaxe valide : **1/1** - TypeScript/Zod/YAML valides
- [x] Code fonctionnel : **1/1** - Mock operationnel
- [x] Exemples concrets : **1/1** - Cas d'usage reels
- [ ] Tests pertinents : **0/1** - Tests unitaires a ajouter
- [x] Documentation complete : **1/1** - 8 modules + commentaires
- [x] Coherence entre blocs : **1/1** - Pas de contradiction
- [x] Style coherent : **1/1** - Uniforme partout
- [x] Pas de redondance : **1/1** - Contenu unique par bloc

**Sous-total Qualite : 9/10**

---

### SCORE TOTAL : 23/25

**Statut** : EXCELLENT

**Detail des manquements** :
1. Tests avec scenarios varies : Ajouter des tests unitaires pour chaque module
2. Tests pertinents : Creer des tests d'integration pour le flux 7 etapes

**Corrections proposees** :
- Creer un fichier de tests (tests/pev4.1.test.ts) couvrant les 7 etapes
- Ajouter des tests de detection de type de projet
- Tester les cas limites (projet vide, projet contradictoire)`;

    case 'ameliorer':
      return `## Resultat - Etape 7 : Amelioration

### Ameliorations prioritaires

1. **Integration d'un LLM reel** (Critique)
   - Remplacer le mock par un appel a l'API OpenAI, Claude ou Mistral
   - Implementer le streaming des reponses pour une meilleure UX
   - Ajouter la gestion des tokens et le retry automatique

2. **Systeme de reprise** (Important)
   - Permettre de reprendre une session a n'importe quelle etape
   - Ajouter un mecanisme de rollback en cas d'erreur
   - Stocker les versions intermediaires des outputs

3. **Detection de type amelioree** (Important)
   - Utiliser un LLM pour la classification au lieu de mots-cles
   - Ajouter la possibility pour l'utilisateur de forcer le type de projet
   - Implementer un feedback loop (utilisateur corrige le type detecte)

### Cas limites non couverts

- **Projet vide ou trop court** (< 50 chars) : Risque de detection echouee
- **Projet contradictoire** : Contient des elements de types incompatibles
- **Projet multilingue** : Melange de langues non gere
- **Projet avec code binaire** : Contenu non textuel non traitable

### Tests additionnels suggères

1. Test avec un projet web complet (Next.js + Prisma)
2. Test avec un pipeline ETL (Python + Airflow)
3. Test avec un agent IA (LangChain + RAG)
4. Test avec un projet minimal (1 fichier texte)
5. Test avec un projet contradictoire (web + CLI)
6. Test de regression : verifier que les blocs A+H sont toujours presents

### Evolutions futures

1. **v4.2** : Support multi-utilisateurs avec authentification
2. **v4.3** : Interface d'edition des blocs generes
3. **v5.0** : Mode collaboratif (plusieurs IA travaillent sur le meme projet)

### Conclusion

Le PEK v4.1 realise la fusion reussie entre la plateforme Next.js de la v4 et le moteur methodologique de la v3.1. Les 7 etapes CoT, les blocs adaptatifs A-J et le systeme de validation 25 points sont pleinement integres dans l'architecture API. Le passage de 3 etapes generiques a 7 etapes semantiques represente une amelioration de 133% de la granularite du traitement. La prochaine etape critique est l'integration d'un LLM reel pour des reponses contextuellement riches.`;

    default:
      return `[MOCK LLM] Reponse par defaut pour : ${prompt.substring(0, 100)}...`;
  }
}

// --- Production LLM (placeholder) ---

async function generateRealResponse(prompt: string): Promise<string> {
  // Placeholder pour l'intégration d'un vrai LLM
  // En production, utiliser fetch() vers l'API du LLM configuré
  const model = process.env.LLM_MODEL || 'gpt-4';

  // Simulation d'un délai réseau
  await new Promise((r) => setTimeout(r, 500));

  return `[PRODUCTION LLM - ${model}] Ce mode n'est pas encore configure. Prompt recu : ${prompt.substring(0, 100)}...`;
}