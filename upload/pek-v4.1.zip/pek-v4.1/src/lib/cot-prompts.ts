/**
 * cot-prompts.ts — Prompts complets du Chain-of-Thought 7 étapes
 * Chaque fonction construit le prompt complet de l'étape correspondante,
 * en injectant le knowledge base contextuel.
 */

export const STEP_NAMES = [
  'comprendre',
  'decomposer',
  'extraire',
  'structurer',
  'generer',
  'valider',
  'ameliorer',
] as const;

export type StepName = (typeof STEP_NAMES)[number];

export const STEP_LABELS: Record<StepName, string> = {
  comprendre: 'ETAPE 1 : COMPREHENSION',
  decomposer: 'ETAPE 2 : DECOMPOSITION',
  extraire: 'ETAPE 3 : EXTRACTION',
  structurer: 'ETAPE 4 : STRUCTURATION',
  generer: 'ETAPE 5 : GENERATION',
  valider: 'ETAPE 6 : VALIDATION',
  ameliorer: 'ETAPE 7 : AMELIORATION',
};

// Modules de knowledge pertinents pour chaque étape
export const STEP_KNOWLEDGE_MODULES: Record<StepName, string[]> = {
  comprendre: ['0', '1', '3'],       // System, Role, Context
  decomposer: ['0', '4'],             // System, Structure (blocs A-J)
  extraire: ['0', '2', '3'],          // System, Constraints, Context
  structurer: ['0', '4', '5'],        // System, Structure, Formatting
  generer: ['0', '1', '2', '4', '5'],// System, Role, Constraints, Structure, Formatting
  valider: ['0', '2', '6'],           // System, Constraints, QualityControl
  ameliorer: ['0', '6'],              // System, QualityControl
};

function buildContextDirective(stepName: StepName, knowledgeContent: string): string {
  const modules = STEP_KNOWLEDGE_MODULES[stepName];
  return `
## CONTEXTE ET CONNAISSANCES (Knowledge Base PEK v4.1)

Voici les modules de connaissances pertinents pour cette étape (${modules.join(', ')}) :

${knowledgeContent}

---

Tu dois t'appuyer sur ces connaissances pour accomplir cette étape.
Respecte scrupuleusement les règles, principes et méthodologies définis ci-dessus.
`;
}

export function buildCoTPrompt(
  stepNumber: number,
  stepName: StepName,
  userInput: string,
  previousOutput: string | null,
  knowledgeContent: string
): string {
  const context = buildContextDirective(stepName, knowledgeContent);
  const previousSection = previousOutput
    ? `\n## RESULTAT DE L'ETAPE PRECEDENTE\n\n${previousOutput}\n\n---\n`
    : '';

  switch (stepName) {
    case 'comprendre':
      return `${context}
${previousSection}
## ${STEP_LABELS.comprendre}

**Objectif** : Saisir globalement le projet fourni ci-dessous.

**Instructions** :
1. Lire l'integralite du materiel fourni
2. Identifier le type de projet (web, pipeline, agent IA, CLI, etc.)
3. Noter l'objectif principal en une phrase
4. Lister les contraintes majeures
5. Determiner le niveau de complexite (simple, moyen, complexe)
6. Identifier le format d'entree

**Format de sortie attendu** :
- **Type de projet** : [type detecte]
- **Objectif principal** : [une phrase]
- **Contraintes majeures** : [liste]
- **Niveau de complexite** : [simple/moyen/complex]
- **Format d'entree** : [format detecte]
- **Resume executif** : [3-5 phrases decrivant le projet]

## MATERIEL A ANALYSER

${userInput}`;

    case 'decomposer':
      return `${context}
${previousSection}
## ${STEP_LABELS.decomposer}

**Objectif** : Structurer mentalement le projet et determiner la structure de sortie adaptative.

**Instructions** :
1. Identifier les composants principaux du projet
2. Cartographier les dependances entre composants
3. Repérer les patterns recurrents
4. Classer les informations par categorie
5. **Determine quels blocs de sortie (A-J) sont pertinents** pour ce projet, en te referant au MODULE 4 (Structure) de la Knowledge Base
6. Justifier chaque bloc selectionne et chaque bloc exclu

**Format de sortie attendu** :
- **Composants principaux** : [liste structuree]
- **Dependances** : [carte des dependances]
- **Patterns identifies** : [liste]
- **Type de projet confirme** : [type]
- **Blocs de sortie selectionnes** : [liste des blocs A-J avec justification]
- **Blocs exclus et raison** : [liste avec justification]

**Reponse du resume** (etape 1) a utiliser comme base :
${previousOutput || '[Aucun resultat precedent]'}  `;

    case 'extraire':
      return `${context}
${previousSection}
## ${STEP_LABELS.extraire}

**Objectif** : Extraire systematiquement tous les elements pertinents du projet.

**Instructions** :
Appliquer la checklist suivante :
- [ ] Objectif principal + sous-objectifs
- [ ] Regles absolues + limitations techniques
- [ ] Etapes successives + decisions prises
- [ ] Format de sortie + blocs/sections selectionnes
- [ ] Style + langue + niveau de detail
- [ ] Scripts + plateformes + bibliotheques
- [ ] Donnees d'entree (types, schemas, formats)
- [ ] Donnees de sortie attendues

**Format de sortie attendu** :
Liste exhaustive et structuree de tous les elements extraits, organises par categorie.

**Blocs selectionnes** (de l'etape 2) : ${previousOutput?.includes('Blocs de sortie') ? 'voir section precedente' : 'A+H par defaut'}`;

    case 'structurer':
      return `${context}
${previousSection}
## ${STEP_LABELS.structurer}

**Objectif** : Organiser les elements extraits dans l'architecture du kit PEK.

**Instructions** :
1. Mapper chaque element extrait au module de knowledge correspondant :
   - System (comportement general)
   - Role (identite et expertise)
   - Constraints (regles absolues)
   - Context (informations projet)
   - Structure (architecture de sortie, blocs A-J)
   - Formatting (style et presentation)
   - QualityControl (validation)
   - Reasoning (processus CoT)
2. Identifier les lacunes (elements non mappables)
3. Proposer une organisation optimale

**Format de sortie attendu** :
Pour chaque module, lister les elements qui y seront places.
Mettre en evidence les lacunes identifiees et les propositions de resolution.`;

    case 'generer':
      return `${context}
${previousSection}
## ${STEP_LABELS.generer}

**Objectif** : Produire le contenu complet du Prompt Engineering Kit.

**Instructions** :
1. Generer chaque artefact demandé dans l'ordre :
   - Resume executif (Bloc A)
   - Puis les blocs selectionnes a l'etape 2 dans l'ordre logique
   - Terminer par les recommandations (Bloc H)
2. Pour chaque bloc, respecter le format et le contenu specifies dans le MODULE 4 (Structure)
3. Appliquer les regles de formatting du MODULE 5
4. Respecter les contraintes du MODULE 2

**Format de sortie attendu** :
Contenu complet de chaque bloc selectionne, avec titres, sections et sous-sections appropriees.
Le contenu doit etre directement utilisable et coherent avec les etapes precedentes.`;

    case 'valider':
      return `${context}
${previousSection}
## ${STEP_LABELS.valider}

**Objectif** : Verifier la qualite et la coherence du contenu genere.

**Instructions** :
Appliquer la checklist de validation du MODULE 6 (QualityControl) :

**Checklist Pre-Generation (5 points)** :
1. Toutes les informations requises sont presentes ?
2. Le contexte est clair et complet ?
3. Les contraintes sont bien definies et non contradictoires ?
4. Le format d'entree est identifie ?
5. Les exemples sont pertinents et diversifies ?

**Checklist Post-Generation (10 points)** :
1. Tous les blocs selectionnes sont presents et complets ?
2. Les schemas sont valides ?
3. Les exemples sont de domaines varies ?
4. Tests avec scenarios varies ?
5. Aucun contenu vide sans notification ?
6. Tous les schemas definis ?
7. References croisees valides ?
8. Versionning coherent ?
9. Terminologie uniforme ?
10. Pas de contradictions entre blocs ?

**Checklist Qualite (10 points)** :
1. Langage clair et sans ambiguite ?
2. Formatting correct ?
3. Syntaxe valide ?
4. Code fonctionnel (si applicable) ?
5. Exemples concrets et realistes ?
6. Tests pertinents ?
7. Documentation complete ?
8. Coherence entre blocs ?
9. Style coherent ?
10. Pas de redondance ?

**Format de sortie attendu** :
- Score par categorie (X/5 + Y/10 + Z/10)
- Score total : N/25
- Statut : PARFAIT / EXCELLENT / ACCEPTABLE / A REPRENDRE
- Detail des erreurs ou manquements detectes
- Corrections proposees`;

    case 'ameliorer':
      return `${context}
${previousSection}
## ${STEP_LABELS.ameliorer}

**Objectif** : Proposer des evolutions et ameliorations.

**Instructions** :
1. Identifier 3 points d'amelioration prioritaires
2. Noter les cas limites non couverts par le kit
3. Suggerer des tests additionnels
4. Documenter les evolutions futures possibles
5. Proposer des optimisations de performance ou d'ergonomie

**Format de sortie attendu** :
- **Ameliorations prioritaires** : [liste justifiee]
- **Cas limites non couverts** : [liste avec gravite]
- **Tests additionnels suggères** : [liste]
- **Evolutions futures** : [liste priorisee]
- **Conclusion finale** : [synthese du projet complete]`;

    default:
      return `${context}\n${userInput}`;
  }
}