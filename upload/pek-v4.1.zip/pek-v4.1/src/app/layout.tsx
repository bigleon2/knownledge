export const metadata = {
  title: 'PEK v4.1 — Prompt Engineering Kit',
  description: 'Moteur de prompt engineering 7 etapes CoT avec blocs adaptatifs A-J et validation 25 points',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fr">
      <body style={{ margin: 0, padding: 0 }}>
        {children}
      </body>
    </html>
  );
}