import { NextResponse } from 'next/server';
export async function GET() {
  return NextResponse.json({
    version: '4.1.0',
    status: 'ok',
    modules: 8,
    steps: 7,
    blocks: 'A-J',
    validationMaxScore: 25,
  });
}