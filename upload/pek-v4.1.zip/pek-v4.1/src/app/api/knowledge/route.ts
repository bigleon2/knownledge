import { NextResponse } from 'next/server';
import fs from 'fs/promises';
import path from 'path';
import { withRateLimit } from '@/lib/rate-limit';

async function handler(req: Request) {
  try {
    const kbPath = path.join(process.cwd(), 'KNOWLEDGE.md');
    const fullContent = await fs
      .readFile(kbPath, 'utf-8')
      .catch(() => '# KNOWLEDGE BASE\nMode Low-Resource : knowledge base non disponible.');

    // Support du paramètre ?module=X pour retourner un module spécifique
    const { searchParams } = new URL(req.url);
    const moduleParam = searchParams.get('module');

    if (moduleParam) {
      const lines = fullContent.split('\n');
      const moduleLines: string[] = [];
      let inTarget = false;
      let found = false;

      for (const line of lines) {
        const match = line.match(new RegExp(`^## MODULE ${moduleParam}\\b`, 'i'));
        if (match) {
          inTarget = true;
          found = true;
          moduleLines.push(line);
          continue;
        }
        if (inTarget) {
          // Fin du module quand on rencontre un autre module
          if (line.match(/^## MODULE \d+/i)) {
            inTarget = false;
            break;
          }
          moduleLines.push(line);
        }
      }

      if (!found) {
        return NextResponse.json(
          { error: `Module ${moduleParam} non trouve`, availableModules: ['0', '1', '2', '3', '4', '5', '6', '7'] },
          { status: 404 }
        );
      }

      return NextResponse.json({
        module: moduleParam,
        content: moduleLines.join('\n'),
      });
    }

    // Retourner tout le knowledge base
    // Compter les modules pour un résumé
    const moduleCount = (fullContent.match(/^## MODULE \d+/gm) || []).length;

    return NextResponse.json({
      version: '4.1',
      moduleCount,
      content: fullContent,
    });
  } catch (err) {
    return NextResponse.json({ error: 'Erreur de lecture' }, { status: 500 });
  }
}

export const GET = withRateLimit(handler);