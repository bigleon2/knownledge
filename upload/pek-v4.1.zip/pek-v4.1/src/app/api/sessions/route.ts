import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { CreateSessionSchema } from '@/lib/validators';
import { withRateLimit } from '@/lib/rate-limit';

async function handler(req: Request) {
  try {
    const body = await req.json().catch(() => ({}));
    const { title, projectType } = CreateSessionSchema.parse(body);

    const session = await db.session.create({
      data: {
        title: title || 'Nouvelle session PEK v4.1',
        projectType: projectType || null,
      },
    });

    return NextResponse.json(
      {
        id: session.id,
        title: session.title,
        projectType: session.projectType,
        status: session.status,
        createdAt: session.createdAt,
        message: 'Session creee. Envoyez les etapes 1-7 via POST /api/sessions/' + session.id + '/execute',
        nextStep: 1,
      },
      { status: 201 }
    );
  } catch (err: unknown) {
    const message =
      err && typeof err === 'object' && 'name' in err && err.name === 'ZodError'
        ? 'Donnees invalides'
        : err instanceof Error
          ? err.message
          : 'Erreur interne';
    return NextResponse.json({ error: message }, { status: 400 });
  }
}

export const POST = withRateLimit(handler);