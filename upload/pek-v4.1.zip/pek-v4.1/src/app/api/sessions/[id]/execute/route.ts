import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { generate } from '@/lib/llm';
import {
  ExecuteStepSchema,
  SessionIdSchema,
  STEP_NAME_FROM_NUMBER,
} from '@/lib/validators';
import { buildCoTPrompt, STEP_NAMES, STEP_KNOWLEDGE_MODULES, type StepName } from '@/lib/cot-prompts';
import { selectBlocks, type Block } from '@/lib/adaptive-blocks';
import { validate, type ValidationResult } from '@/lib/validation';
import { withRateLimit } from '@/lib/rate-limit';
import fs from 'fs/promises';
import path from 'path';

// Charger le knowledge base une seule fois (cache)
let cachedKnowledge: string | null = null;

async function getKnowledgeContent(): Promise<string> {
  if (cachedKnowledge) return cachedKnowledge;
  const kbPath = path.join(process.cwd(), 'KNOWLEDGE.md');
  cachedKnowledge = await fs.readFile(kbPath, 'utf-8').catch(() => {
    return '# KNOWLEDGE BASE\nMode Low-Resource : knowledge base non disponible.';
  });
  return cachedKnowledge;
}

// Extraire uniquement les modules pertinents du knowledge
function extractRelevantModules(
  fullKnowledge: string,
  moduleNumbers: string[]
): string {
  const lines = fullKnowledge.split('\n');
  const modules: string[] = [];

  let currentModule: string[] = [];
  let inTargetModule = false;
  let currentModuleNum = '';

  for (const line of lines) {
    // Détecter le début d'un module
    const moduleMatch = line.match(/^## MODULE (\d+)/i);
    if (moduleMatch) {
      // Sauvegarder le module précédent si cible
      if (inTargetModule && currentModule.length > 0) {
        modules.push(currentModule.join('\n'));
      }
      currentModuleNum = moduleMatch[1];
      currentModule = [line];
      inTargetModule = moduleNumbers.includes(currentModuleNum);
      continue;
    }

    if (inTargetModule) {
      currentModule.push(line);
    }
  }

  // Ne pas oublier le dernier module
  if (inTargetModule && currentModule.length > 0) {
    modules.push(currentModule.join('\n'));
  }

  return modules.length > 0
    ? modules.join('\n\n---\n\n')
    : fullKnowledge.substring(0, 3000); // Fallback
}

async function handler(
  req: Request,
  context: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await context.params;

    // 1. Valider l'ID de session
    SessionIdSchema.parse(id);

    // 2. Vérifier que la session existe
    const session = await db.session.findUnique({ where: { id } });
    if (!session) {
      return NextResponse.json({ error: 'Session non trouvee' }, { status: 404 });
    }

    // 3. Valider le body
    const body = await req.json();
    const {
      currentStep,
      stepName: bodyStepName,
      userInput,
      previousOutput,
      projectType: bodyProjectType,
      selectedBlocks: bodySelectedBlocks,
    } = ExecuteStepSchema.parse(body);

    // 4. Vérifier le contrôle séquentiel des étapes
    const existingSteps = await db.sessionStep.findMany({
      where: { sessionId: id },
      orderBy: { step: 'asc' },
    });
    const completedStepNumbers = existingSteps.map((s) => s.step);

    if (completedStepNumbers.includes(currentStep)) {
      return NextResponse.json(
        { error: `Etape ${currentStep} deja executee` },
        { status: 409 }
      );
    }
    if (currentStep > 1 && !completedStepNumbers.includes(currentStep - 1)) {
      return NextResponse.json(
        { error: `L'etape ${currentStep - 1} doit etre executee avant l'etape ${currentStep}` },
        { status: 400 }
      );
    }

    // 5. Récupérer le previousOutput complet depuis la DB (pas le preview tronqué du frontend)
    let resolvedPreviousOutput = previousOutput || null;
    if (!resolvedPreviousOutput && currentStep > 1) {
      const prevStep = existingSteps.find((s) => s.step === currentStep - 1);
      if (prevStep) {
        resolvedPreviousOutput = prevStep.output;
      }
    }

    // 6. Déterminer le nom de l'étape
    const stepName = (bodyStepName ||
      STEP_NAME_FROM_NUMBER[currentStep]) as StepName;

    if (!stepName || !STEP_NAMES.includes(stepName)) {
      return NextResponse.json(
        { error: `Nom d'étape invalide: ${stepName}` },
        { status: 400 }
      );
    }

    // 7. Charger le knowledge base (modules pertinents)
    const fullKnowledge = await getKnowledgeContent();
    const relevantModules = STEP_KNOWLEDGE_MODULES[stepName] || ['0'];
    const knowledgeContent = extractRelevantModules(
      fullKnowledge,
      relevantModules
    );

    // 8. Sélection des blocs adaptatifs (étape 2)
    let selectedBlocks: Block[] | null = null;
    let detectedProjectType: string | null = bodyProjectType || null;

    if (currentStep === 2 || bodyProjectType) {
      const blockResult = selectBlocks(
        detectedProjectType,
        userInput + (previousOutput || '')
      );
      selectedBlocks = blockResult.blocks;
      detectedProjectType = blockResult.projectType;

      // Mettre à jour la session avec le type de projet et les blocs
      await db.session.update({
        where: { id },
        data: {
          projectType: detectedProjectType,
          selectedBlocks: JSON.stringify(selectedBlocks),
        },
      });
    } else if (bodySelectedBlocks) {
      selectedBlocks = bodySelectedBlocks;
    } else {
      // Récupérer les blocs déjà sélectionnés depuis la session (déjà chargée en étape 2)
      if (session.selectedBlocks) {
        try {
          selectedBlocks = JSON.parse(session.selectedBlocks) as Block[];
        } catch {
          selectedBlocks = null;
        }
      }
    }

    // 9. Construire le prompt CoT complet
    const fullPrompt = buildCoTPrompt(
      currentStep,
      stepName,
      userInput,
      resolvedPreviousOutput,
      knowledgeContent
    );

    // 10. Appeler le LLM avec le prompt complet
    const output = await generate(fullPrompt, stepName);

    // 11. Validation (étape 6 uniquement)
    let validationScore: number | null = null;
    let validationResult: ValidationResult | null = null;

    if (currentStep === 6) {
      // Récupérer tous les outputs précédents pour la validation
      const allSteps = await db.sessionStep.findMany({
        where: { sessionId: id },
        orderBy: { step: 'asc' },
      });
      const previousOutputs = allSteps.map((s) => s.output);

      validationResult = validate(output, selectedBlocks, previousOutputs);
      validationScore = validationResult.score;

      // Mettre à jour le score de la session
      await db.session.update({
        where: { id },
        data: { validationScore },
      });
    }

    // 12. Persister l'étape
    const step = await db.sessionStep.create({
      data: {
        sessionId: id,
        step: currentStep,
        stepName,
        input: userInput,
        output,
        selectedBlocks: selectedBlocks ? JSON.stringify(selectedBlocks) : null,
        validationScore,
        projectType: detectedProjectType,
      },
    });

    // 13. Marquer la session comme complétée si c'est l'étape 7
    if (currentStep === 7) {
      await db.session.update({
        where: { id },
        data: { status: 'completed' },
      });
    }

    // 14. Retourner la réponse
    const nextStep = currentStep < 7 ? currentStep + 1 : null;
    return NextResponse.json({
      step: currentStep,
      stepName,
      output,
      selectedBlocks,
      projectType: detectedProjectType,
      validationScore,
      validationResult: validationResult || undefined,
      stepId: step.id,
      nextStep,
    });
  } catch (err: unknown) {
    if (err && typeof err === 'object' && 'code' in err && (err as { code: string }).code === 'P2002') {
      return NextResponse.json({ error: 'Etape deja executee (conflit)' }, { status: 409 });
    }
    if (err && typeof err === 'object' && 'code' in err && (err as { code: string }).code === 'P2025') {
      return NextResponse.json({ error: 'Session non trouvee' }, { status: 404 });
    }
    const message =
      err && typeof err === 'object' && 'name' in err && (err as { name: string }).name === 'ZodError'
        ? 'Donnees invalides'
        : err instanceof Error
          ? err.message
          : 'Erreur interne';
    const status = message === 'Session non trouvee' ? 404 : 400;
    return NextResponse.json({ error: message }, { status });
  }
}

export const POST = withRateLimit(handler);