import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { SessionIdSchema } from '@/lib/validators';
import { withRateLimit } from '@/lib/rate-limit';
import { BLOCK_LABELS, type Block } from '@/lib/adaptive-blocks';

async function handler(
  req: Request,
  context: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await context.params;
    SessionIdSchema.parse(id);

    const session = await db.session.findUnique({
      where: { id },
      include: { steps: { orderBy: { step: 'asc' } } },
    });

    if (!session) {
      return NextResponse.json({ error: 'Session non trouvee' }, { status: 404 });
    }

    // Récupérer les blocs sélectionnés (depuis la session ou de l'étape 2)
    let selectedBlocks: string[] = ['A', 'H']; // Par défaut
    try {
      if (session.selectedBlocks) {
        selectedBlocks = JSON.parse(session.selectedBlocks);
      } else {
        const step2 = session.steps.find((s) => s.step === 2);
        if (step2?.selectedBlocks) {
          selectedBlocks = JSON.parse(step2.selectedBlocks);
        }
      }
    } catch {
      // Garder les blocs par défaut
    }

    // Générer le Markdown structuré avec blocs
    let md = `# ${session.title}\n\n`;
    md += `**PEK v4.1** | Type de projet : ${session.projectType || 'non detecte'} | `;
    md += `Blocs selectionnes : ${selectedBlocks.join(', ')} | `;
    md += `Score de validation : ${session.validationScore ?? 'non evalue'}/25\n\n`;
    md += `---\n\n`;

    // Pour chaque bloc sélectionné, extraire le contenu pertinent des étapes
    for (const block of selectedBlocks) {
      const blockLabel = BLOCK_LABELS[block as Block] || block;
      md += `## BLOC ${block} : ${blockLabel}\n\n`;

      switch (block) {
        case 'A': // Résumé exécutif → Étape 1
          {
            const step = session.steps.find((s) => s.step === 1);
            md += step?.output || '*Non genere*\n';
          }
          break;

        case 'B': // Architecture → Étape 2 (décomposition)
          {
            const step = session.steps.find((s) => s.step === 2);
            if (step) {
              // Extraire la section "Composants principaux" et "Dépendances"
              const lines = step.output.split('\n');
              let capturing = false;
              let capture = false;
              for (const line of lines) {
                if (line.includes('Composants principaux') || line.includes('Architecture')) capturing = true;
                if (line.includes('Blocs de sortie selectionnes')) capture = true;
                if (capture) { md += line + '\n'; }
                else if (capturing) { md += line + '\n'; }
                if (capture && line.trim() === '') break;
                if (capturing && !capture && line.includes('Patterns') && !line.includes('**Patterns')) capturing = false;
              }
            } else {
              md += '*Non genere*\n';
            }
          }
          break;

        case 'C': // Prompts/Instructions → Étape 3 (extraction) + Étape 4 (structuration)
          {
            const step3 = session.steps.find((s) => s.step === 3);
            const step4 = session.steps.find((s) => s.step === 4);
            md += '### Elements extraits (Etape 3)\n\n';
            md += step3?.output || '*Non genere*\n';
            md += '\n### Structuration (Etape 4)\n\n';
            md += step4?.output || '*Non genere*\n';
          }
          break;

        case 'D': // Données & Schemas → Étape 3 + Étape 4
          {
            const step3 = session.steps.find((s) => s.step === 3);
            const step4 = session.steps.find((s) => s.step === 4);
            if (step3) {
              const lines = step3.output.split('\n');
              let capturing = false;
              for (const line of lines) {
                if (line.toLowerCase().includes('données') || line.toLowerCase().includes('donnees') || line.toLowerCase().includes('schemas') || line.toLowerCase().includes('format')) {
                  capturing = true;
                }
                if (capturing) md += line + '\n';
                if (capturing && line.trim() === '' && !line.toLowerCase().includes('données') && !line.toLowerCase().includes('donnees')) {
                  capturing = false;
                }
              }
            }
            if (step4) md += '\n' + step4.output + '\n';
            if (!step3 && !step4) md += '*Non genere*\n';
          }
          break;

        case 'E': // Contraintes → Étape 3
          {
            const step = session.steps.find((s) => s.step === 3);
            if (step) {
              const lines = step.output.split('\n');
              let capturing = false;
              for (const line of lines) {
                if (line.toLowerCase().includes('regle') || line.toLowerCase().includes('contrainte') || line.toLowerCase().includes('limitation')) {
                  capturing = true;
                }
                if (capturing) md += line + '\n';
                if (capturing && line.trim() === '' && !line.toLowerCase().includes('regle') && !line.toLowerCase().includes('contrainte')) {
                  capturing = false;
                }
              }
              if (!md.includes('regle') && !md.includes('contrainte')) md += step.output + '\n';
            } else {
              md += '*Non genere*\n';
            }
          }
          break;

        case 'F': // Résultats → Étape 5 (génération)
          {
            const step = session.steps.find((s) => s.step === 5);
            md += step?.output || '*Non genere*\n';
          }
          break;

        case 'G': // Guide → Synthèse des étapes 1-5
          {
            md += '### Guide d\'utilisation du flux PEK v4.1\n\n';
            md += '1. **Comprehension** (Etape 1) : Fournir la description du projet\n';
            md += '2. **Decomposition** (Etape 2) : Le systeme detecte le type et selectionne les blocs\n';
            md += '3. **Extraction** (Etape 3) : Extraction systematique des elements\n';
            md += '4. **Structuration** (Etape 4) : Organisation dans l\'architecture 8 modules\n';
            md += '5. **Generation** (Etape 5) : Production des artefacts par bloc\n';
            md += '6. **Validation** (Etape 6) : Scoring automatique 25 points\n';
            md += '7. **Amelioration** (Etape 7) : Recommandations et evolutions\n';
          }
          break;

        case 'H': // Recommandations → Étape 7
          {
            const step = session.steps.find((s) => s.step === 7);
            md += step?.output || '*Non genere (derniere etape non executee)*\n';
          }
          break;

        case 'I': // Tests & Validation → Étape 6
          {
            const step = session.steps.find((s) => s.step === 6);
            md += step?.output || '*Non genere*\n';
          }
          break;

        case 'J': // Glossaire → extraction depuis toutes les étapes
          {
            md += '### Termes cles du projet\n\n';
            md += '- **PEK** : Prompt Engineering Kit\n';
            md += '- **CoT** : Chain-of-Thought (raisonnement en chaine)\n';
            md += '- **Blocs A-J** : 10 blocs de sortie adaptatifs\n';
            md += '- **Knowledge Base** : 8 modules de connaissances\n';
            md += '- **Scoring 25 pts** : Systeme de validation en 3 checklists\n';
            md += `- **Type de projet** : ${session.projectType || 'non detecte'}\n`;
          }
          break;

        default:
          md += `*Bloc ${block} non reconnu*\n`;
      }

      md += '\n---\n\n';
    }

    // Ajouter l'historique brut des étapes
    md += '## Historique complet des etapes\n\n';
    for (const s of session.steps) {
      md += `### Etape ${s.step} : ${s.stepName}\n\n`;
      md += s.output + '\n\n---\n\n';
    }

    return new Response(md, {
      headers: {
        'Content-Type': 'text/markdown; charset=utf-8',
        'Content-Disposition': `attachment; filename="pek-v4.1-${id.substring(0, 8)}.md"`,
      },
    });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Erreur d\'export';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}

export const GET = withRateLimit(handler);