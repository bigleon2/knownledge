import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { SessionIdSchema } from '@/lib/validators';
import { withRateLimit } from '@/lib/rate-limit';

async function handler(
  req: Request,
  context: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await context.params;
    SessionIdSchema.parse(id);

    const session = await db.session.findUnique({
      where: { id },
      include: { steps: { orderBy: { step: 'asc' } } },
    });

    if (!session) {
      return NextResponse.json({ error: 'Session non trouvee' }, { status: 404 });
    }

    // Déterminer la prochaine étape
    const completedSteps = session.steps.map((s) => s.step);
    let nextStep = 1;
    while (completedSteps.includes(nextStep) && nextStep <= 7) {
      nextStep++;
    }

    // Parser les blocs sélectionnés
    let selectedBlocks: string[] | null = null;
    try {
      if (session.selectedBlocks) {
        selectedBlocks = JSON.parse(session.selectedBlocks);
      }
    } catch {
      // Ignorer
    }

    return NextResponse.json({
      id: session.id,
      title: session.title,
      status: session.status,
      projectType: session.projectType,
      selectedBlocks,
      validationScore: session.validationScore,
      nextStep: nextStep > 7 ? null : nextStep,
      completedSteps,
      totalSteps: 7,
      steps: session.steps.map((s) => ({
        id: s.id,
        step: s.step,
        stepName: s.stepName,
        outputPreview: s.output.substring(0, 200) + (s.output.length > 200 ? '...' : ''),
        validationScore: s.validationScore,
        selectedBlocks: s.selectedBlocks ? JSON.parse(s.selectedBlocks) : null,
        createdAt: s.createdAt,
      })),
      createdAt: session.createdAt,
      updatedAt: session.updatedAt,
    });
  } catch (err: unknown) {
    const message =
      err && typeof err === 'object' && 'name' in err && err.name === 'ZodError'
        ? 'ID invalide'
        : err instanceof Error
          ? err.message
          : 'Erreur interne';
    return NextResponse.json({ error: message }, { status: 400 });
  }
}

export const GET = withRateLimit(handler);