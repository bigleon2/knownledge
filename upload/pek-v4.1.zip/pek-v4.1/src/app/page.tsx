'use client';

import { useState, useEffect, useCallback } from 'react';

const STEP_LABELS: Record<number, string> = {
  1: 'Comprehension',
  2: 'Decomposition',
  3: 'Extraction',
  4: 'Structuration',
  5: 'Generation',
  6: 'Validation',
  7: 'Amelioration',
};

const STEP_ICONS: Record<number, string> = {
  1: '1',
  2: '2',
  3: '3',
  4: '4',
  5: '5',
  6: '6',
  7: '7',
};

const COLORS = {
  bg: '#0f172a',
  card: '#1e293b',
  border: '#334155',
  primary: '#3b82f6',
  primaryLight: '#60a5fa',
  success: '#22c55e',
  warning: '#f59e0b',
  danger: '#ef4444',
  text: '#e2e8f0',
  textMuted: '#94a3b8',
  textDim: '#64748b',
};

interface Step {
  id: string;
  step: number;
  stepName: string;
  outputPreview: string;
  validationScore: number | null;
  selectedBlocks: string[] | null;
  createdAt: string;
}

interface SessionData {
  id: string;
  title: string;
  status: string;
  projectType: string | null;
  selectedBlocks: string[] | null;
  validationScore: number | null;
  nextStep: number | null;
  completedSteps: number[];
  totalSteps: number;
  steps: Step[];
}

export default function Home() {
  const [session, setSession] = useState<SessionData | null>(null);
  const [sessionId, setSessionId] = useState('');
  const [loading, setLoading] = useState(false);
  const [input, setInput] = useState('');
  const [currentStep, setCurrentStep] = useState(1);
  const [error, setError] = useState('');
  const [expandedStep, setExpandedStep] = useState<number | null>(null);
  const [stepOutput, setStepOutput] = useState('');

  const API_BASE = '';

  // Créer une session
  const createSession = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const res = await fetch(`${API_BASE}/api/sessions`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title: 'Session PEK v4.1' }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      setSessionId(data.id);
      setSession({ ...data, steps: [], completedSteps: [] });
      setCurrentStep(1);
      setInput('');
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : 'Erreur');
    } finally {
      setLoading(false);
    }
  }, []);

  // Recharger la session
  const reloadSession = useCallback(async () => {
    if (!sessionId) return;
    try {
      const res = await fetch(`${API_BASE}/api/sessions/${sessionId}`);
      const data = await res.json();
      if (res.ok) setSession(data);
    } catch {
      // Silent
    }
  }, [sessionId]);

  // Exécuter une étape
  const executeStep = useCallback(async () => {
    if (!sessionId || !input.trim()) return;
    setLoading(true);
    setError('');
    try {
      const body: Record<string, unknown> = {
        currentStep,
        userInput: input,
        previousOutput:
          session?.steps.find((s) => s.step === currentStep - 1)
            ?.outputPreview || null,
      };

      const res = await fetch(`${API_BASE}/api/sessions/${sessionId}/execute`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);

      setInput('');
      if (data.nextStep) setCurrentStep(data.nextStep);
      setStepOutput(data.output);
      setExpandedStep(currentStep);
      await reloadSession();
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : 'Erreur');
    } finally {
      setLoading(false);
    }
  }, [sessionId, input, currentStep, session, reloadSession]);

  // Export
  const exportSession = useCallback(() => {
    if (!sessionId) return;
    window.open(`${API_BASE}/api/sessions/${sessionId}/export`, '_blank');
  }, [sessionId]);

  // Voir le détail d'une étape
  const fetchStepDetail = useCallback(
    async (stepNum: number) => {
      const step = session?.steps.find((s) => s.step === stepNum);
      if (step?.outputPreview) {
        setStepOutput(
          step.outputPreview.length < 300
            ? step.outputPreview
            : `[Apercu tronque - ${step.outputPreview.length} chars]`
        );
        setExpandedStep(stepNum);
      }
    },
    [session]
  );

  // Auto-reload quand la session est définie
  useEffect(() => {
    if (sessionId) {
      const interval = setInterval(reloadSession, 3000);
      return () => clearInterval(interval);
    }
  }, [sessionId, reloadSession]);

  return (
    <div style={{ background: COLORS.bg, color: COLORS.text, minHeight: '100vh', fontFamily: 'system-ui, -apple-system, sans-serif' }}>
      {/* Header */}
      <header style={{ padding: '1.5rem 2rem', borderBottom: `1px solid ${COLORS.border}`, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <h1 style={{ margin: 0, fontSize: '1.5rem', fontWeight: 700 }}>
            PEK <span style={{ color: COLORS.primary }}>v4.1</span>
          </h1>
          <p style={{ margin: '0.25rem 0 0', color: COLORS.textMuted, fontSize: '0.85rem' }}>
            Prompt Engineering Kit — 7 etapes CoT + Blocs adaptatifs A-J
          </p>
        </div>
        <div style={{ display: 'flex', gap: '0.5rem' }}>
          <button
            onClick={createSession}
            disabled={loading || !!session}
            style={{
              padding: '0.5rem 1rem',
              background: session ? COLORS.card : COLORS.primary,
              color: '#fff',
              border: 'none',
              borderRadius: '6px',
              cursor: session ? 'default' : 'pointer',
              opacity: session ? 0.5 : 1,
              fontSize: '0.85rem',
            }}
          >
            {session ? 'Session active' : 'Nouvelle session'}
          </button>
          {session && (
            <button
              onClick={exportSession}
              style={{
                padding: '0.5rem 1rem',
                background: COLORS.card,
                color: COLORS.text,
                border: `1px solid ${COLORS.border}`,
                borderRadius: '6px',
                cursor: 'pointer',
                fontSize: '0.85rem',
              }}
            >
              Export .md
            </button>
          )}
        </div>
      </header>

      <main style={{ maxWidth: '1200px', margin: '0 auto', padding: '1.5rem 2rem' }}>
        {!session ? (
          /* Etat initial */
          <div style={{ textAlign: 'center', padding: '4rem 0' }}>
            <div style={{ fontSize: '3rem', marginBottom: '1rem' }}>
              <span style={{ color: COLORS.primary }}>7</span> etapes CoT
              <span style={{ margin: '0 0.5rem', color: COLORS.textDim }}>|</span>
              <span style={{ color: COLORS.success }}>10</span> blocs A-J
              <span style={{ margin: '0 0.5rem', color: COLORS.textDim }}>|</span>
              <span style={{ color: COLORS.warning }}>25</span> pts
            </div>
            <p style={{ color: COLORS.textMuted, marginBottom: '2rem' }}>
              Creez une session pour demarrer le traitement Chain-of-Thought
            </p>
            <button
              onClick={createSession}
              style={{
                padding: '0.75rem 2rem',
                background: COLORS.primary,
                color: '#fff',
                border: 'none',
                borderRadius: '8px',
                cursor: 'pointer',
                fontSize: '1rem',
                fontWeight: 600,
              }}
            >
              Demarrer une session
            </button>
            <div style={{ marginTop: '3rem', display: 'flex', justifyContent: 'center', gap: '2rem', flexWrap: 'wrap' }}>
              {[
                { label: 'POST /api/sessions', desc: 'Creer une session' },
                { label: 'POST /api/sessions/[id]/execute', desc: 'Executer une etape CoT' },
                { label: 'GET /api/sessions/[id]/export', desc: 'Exporter en Markdown' },
                { label: 'GET /api/knowledge', desc: 'Knowledge base (8 modules)' },
              ].map((ep) => (
                <div key={ep.label} style={{ background: COLORS.card, borderRadius: '6px', padding: '0.75rem 1rem', maxWidth: '250px' }}>
                  <code style={{ color: COLORS.primaryLight, fontSize: '0.75rem' }}>{ep.label}</code>
                  <p style={{ color: COLORS.textMuted, fontSize: '0.8rem', margin: '0.25rem 0 0' }}>{ep.desc}</p>
                </div>
              ))}
            </div>
          </div>
        ) : (
          /* Session active */
          <div style={{ display: 'grid', gridTemplateColumns: '280px 1fr', gap: '1.5rem', alignItems: 'start' }}>
            {/* Sidebar : Progression */}
            <div>
              <div style={{ background: COLORS.card, borderRadius: '8px', padding: '1rem', border: `1px solid ${COLORS.border}` }}>
                <h3 style={{ margin: '0 0 0.75rem', fontSize: '0.9rem', color: COLORS.textMuted }}>
                  Progression ({session.completedSteps.length}/7)
                </h3>
                <div style={{ background: COLORS.border, borderRadius: '4px', height: '6px', marginBottom: '1rem' }}>
                  <div
                    style={{
                      background: session.status === 'completed' ? COLORS.success : COLORS.primary,
                      borderRadius: '4px',
                      height: '6px',
                      width: `${(session.completedSteps.length / 7) * 100}%`,
                      transition: 'width 0.3s',
                    }}
                  />
                </div>
                {Array.from({ length: 7 }, (_, i) => i + 1).map((step) => {
                  const completed = session.completedSteps.includes(step);
                  const isCurrent = step === (session.nextStep || 8);
                  const stepData = session.steps.find((s) => s.step === step);

                  return (
                    <button
                      key={step}
                      onClick={() => {
                        if (completed) fetchStepDetail(step);
                      }}
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: '0.5rem',
                        width: '100%',
                        padding: '0.5rem 0.6rem',
                        marginBottom: '0.25rem',
                        background: isCurrent ? 'rgba(59,130,246,0.15)' : expandedStep === step ? 'rgba(59,130,246,0.08)' : 'transparent',
                        border: 'none',
                        borderRadius: '4px',
                        cursor: completed ? 'pointer' : 'default',
                        textAlign: 'left',
                        color: completed ? COLORS.text : isCurrent ? COLORS.primaryLight : COLORS.textDim,
                        fontSize: '0.82rem',
                        fontWeight: isCurrent ? 600 : 400,
                      }}
                    >
                      <span
                        style={{
                          width: '22px',
                          height: '22px',
                          borderRadius: '50%',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          fontSize: '0.7rem',
                          fontWeight: 700,
                          background: completed ? COLORS.success : isCurrent ? COLORS.primary : COLORS.border,
                          color: completed || isCurrent ? '#fff' : COLORS.textDim,
                          flexShrink: 0,
                        }}
                      >
                        {completed ? '\u2713' : STEP_ICONS[step]}
                      </span>
                      <span>{STEP_LABELS[step]}</span>
                      {stepData?.validationScore != null && (
                        <span
                          style={{
                            marginLeft: 'auto',
                            fontSize: '0.7rem',
                            padding: '0.1rem 0.4rem',
                            borderRadius: '3px',
                            background:
                              stepData.validationScore >= 22
                                ? 'rgba(34,197,94,0.2)'
                                : stepData.validationScore >= 20
                                  ? 'rgba(245,158,11,0.2)'
                                  : 'rgba(239,68,68,0.2)',
                            color:
                              stepData.validationScore >= 22
                                ? COLORS.success
                                : stepData.validationScore >= 20
                                  ? COLORS.warning
                                  : COLORS.danger,
                          }}
                        >
                          {stepData.validationScore}/25
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>

              {/* Info session */}
              {session.projectType && (
                <div style={{ marginTop: '1rem', background: COLORS.card, borderRadius: '8px', padding: '1rem', border: `1px solid ${COLORS.border}` }}>
                  <p style={{ margin: 0, fontSize: '0.8rem', color: COLORS.textMuted }}>
                    Type : <strong style={{ color: COLORS.text }}>{session.projectType}</strong>
                  </p>
                  {session.selectedBlocks && (
                    <p style={{ margin: '0.25rem 0 0', fontSize: '0.8rem', color: COLORS.textMuted }}>
                      Blocs : <span style={{ color: COLORS.primaryLight }}>{session.selectedBlocks.join(' ')}</span>
                    </p>
                  )}
                </div>
              )}
            </div>

            {/* Main content */}
            <div>
              {/* Input area */}
              {session.nextStep && session.nextStep <= 7 && (
                <div style={{ background: COLORS.card, borderRadius: '8px', padding: '1.25rem', border: `1px solid ${COLORS.border}`, marginBottom: '1.5rem' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.75rem' }}>
                    <h3 style={{ margin: 0 }}>
                      <span style={{ color: COLORS.primary }}>Etape {session.nextStep}</span> : {STEP_LABELS[session.nextStep]}
                    </h3>
                    {session.nextStep === 1 && (
                      <span style={{ fontSize: '0.75rem', color: COLORS.textMuted, background: COLORS.border, padding: '0.2rem 0.5rem', borderRadius: '3px' }}>
                        Premiere etape
                      </span>
                    )}
                  </div>
                  <textarea
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    placeholder={
                      session.nextStep === 1
                        ? 'Collez ici la description de votre projet, votre prompt, ou votre code a analyser...'
                        : session.nextStep === 2
                          ? 'Review du resultat de l\'etape 1. Le systeme va detecter le type de projet et selectionner les blocs A-J...'
                          : `Continuation de l'etape ${session.nextStep - 1}. Le systeme utilise les resultats precedents automatiquement...`
                    }
                    rows={6}
                    style={{
                      width: '100%',
                      background: COLORS.bg,
                      color: COLORS.text,
                      border: `1px solid ${COLORS.border}`,
                      borderRadius: '6px',
                      padding: '0.75rem',
                      fontSize: '0.9rem',
                      resize: 'vertical',
                      boxSizing: 'border-box',
                      fontFamily: 'inherit',
                    }}
                  />
                  {error && (
                    <p style={{ color: COLORS.danger, fontSize: '0.8rem', margin: '0.5rem 0' }}>{error}</p>
                  )}
                  <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: '0.75rem' }}>
                    <button
                      onClick={executeStep}
                      disabled={loading || !input.trim()}
                      style={{
                        padding: '0.6rem 1.5rem',
                        background: loading || !input.trim() ? COLORS.border : COLORS.primary,
                        color: '#fff',
                        border: 'none',
                        borderRadius: '6px',
                        cursor: loading || !input.trim() ? 'default' : 'pointer',
                        fontWeight: 600,
                        fontSize: '0.9rem',
                      }}
                    >
                      {loading ? 'Traitement en cours...' : `Executer l'etape ${session.nextStep}`}
                    </button>
                  </div>
                </div>
              )}

              {/* Session completee */}
              {session.status === 'completed' && (
                <div style={{ background: 'rgba(34,197,94,0.1)', borderRadius: '8px', padding: '1rem', border: `1px solid ${COLORS.success}`, marginBottom: '1.5rem' }}>
                  <strong style={{ color: COLORS.success }}>Session completee</strong>
                  <span style={{ color: COLORS.textMuted, marginLeft: '1rem' }}>
                    Score final : {session.validationScore ?? 'N/A'}/25
                  </span>
                  <div style={{ marginTop: '0.5rem' }}>
                    <button onClick={exportSession} style={{ padding: '0.4rem 1rem', background: COLORS.success, color: '#fff', border: 'none', borderRadius: '4px', cursor: 'pointer', fontSize: '0.85rem' }}>
                      Telecharger le rapport Markdown
                    </button>
                  </div>
                </div>
              )}

              {/* Output detail */}
              {expandedStep && stepOutput && (
                <div style={{ background: COLORS.card, borderRadius: '8px', padding: '1.25rem', border: `1px solid ${COLORS.border}`, marginBottom: '1.5rem' }}>
                  <h3 style={{ margin: '0 0 0.75rem', fontSize: '0.95rem' }}>
                    <span style={{ color: COLORS.primary }}>Etape {expandedStep}</span> : {STEP_LABELS[expandedStep]} — Resultat
                  </h3>
                  <pre
                    style={{
                      whiteSpace: 'pre-wrap',
                      wordBreak: 'break-word',
                      background: COLORS.bg,
                      padding: '1rem',
                      borderRadius: '6px',
                      fontSize: '0.82rem',
                      lineHeight: 1.6,
                      color: COLORS.text,
                      maxHeight: '500px',
                      overflow: 'auto',
                      margin: 0,
                    }}
                  >
                    {stepOutput}
                  </pre>
                </div>
              )}

              {/* Steps list */}
              {session.steps.length > 0 && (
                <div style={{ background: COLORS.card, borderRadius: '8px', padding: '1rem', border: `1px solid ${COLORS.border}` }}>
                  <h3 style={{ margin: '0 0 0.75rem', fontSize: '0.9rem', color: COLORS.textMuted }}>
                    Etapes completees ({session.steps.length})
                  </h3>
                  {[...session.steps].reverse().map((step) => (
                    <div
                      key={step.id}
                      onClick={() => {
                        setExpandedStep(step.step);
                        setStepOutput(step.outputPreview);
                      }}
                      style={{
                        padding: '0.6rem',
                        borderBottom: `1px solid ${COLORS.border}`,
                        cursor: 'pointer',
                        fontSize: '0.82rem',
                      }}
                    >
                      <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                        <span>
                          <strong style={{ color: COLORS.primaryLight }}>Etape {step.step}</strong> : {step.stepName}
                        </span>
                        {step.validationScore != null && (
                          <span style={{ color: step.validationScore >= 22 ? COLORS.success : COLORS.warning }}>
                            {step.validationScore}/25
                          </span>
                        )}
                      </div>
                      <p style={{ margin: '0.25rem 0 0', color: COLORS.textDim, fontSize: '0.78rem' }}>
                        {step.outputPreview.substring(0, 120)}...
                      </p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
      </main>
    </div>
  );
}