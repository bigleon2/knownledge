import type { NextConfig } from 'next'
const nextConfig: NextConfig = {
  compress: true,
  reactStrictMode: true,
  experimental: { serverActions: { bodySizeLimit: '2mb' } },
}
export default nextConfig