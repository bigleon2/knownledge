#!/bin/bash
# start.sh — Démarre PEK v4.1 avec la bonne DB et configuration
DIR="/home/z/my-project/download/pek-v4.1"

# 1. Se placer dans le bon répertoire
cd "$DIR" || exit 1

# 2. Nettoyer les DB parasites
rm -f /home/z/my-project/db/custom.db
rm -f prisma/dev.db

# 3. Créer la DB avec better-sqlite3 (contourne le bug Prisma CLI)
node -e "
const Database = require('better-sqlite3');
const fs = require('fs');
const p = 'prisma/dev.db';
if (fs.existsSync(p)) fs.unlinkSync(p);
const db = new Database(p);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.exec(\`
CREATE TABLE Session (
  id TEXT NOT NULL PRIMARY KEY,
  title TEXT NOT NULL DEFAULT 'Nouvelle session PEK v4.1',
  status TEXT NOT NULL DEFAULT 'active',
  projectType TEXT,
  selectedBlocks TEXT,
  validationScore INTEGER,
  createdAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updatedAt DATETIME NOT NULL
);
CREATE TABLE SessionStep (
  id TEXT NOT NULL PRIMARY KEY,
  sessionId TEXT NOT NULL REFERENCES Session(id) ON DELETE CASCADE,
  step INTEGER NOT NULL,
  stepName TEXT NOT NULL,
  selectedBlocks TEXT,
  validationScore INTEGER,
  projectType TEXT,
  input TEXT,
  output TEXT NOT NULL,
  createdAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(sessionId, step)
);
CREATE INDEX Session_createdAt_idx ON Session(createdAt);
CREATE INDEX SessionStep_sessionId_idx ON SessionStep(sessionId);
\`);
console.log('DB created: ' + p);
db.close();
"

# 4. Configurer l'environnement pour que Prisma utilise NOTRE DB
export DATABASE_URL="file:$DIR/prisma/dev.db"
export LLM_PROVIDER="mock"
export LLM_MODEL="gpt-4"

# 5. Lancer Next.js sur le port 3999
exec npx next dev -p 3999